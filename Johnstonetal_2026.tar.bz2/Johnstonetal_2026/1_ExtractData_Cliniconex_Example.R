
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 2, 2025
# V1

#################################################################################################

                                    #####################
                                    # Declare functions #
                                    #####################

# Function 1
get_consented_data <- function(df){
  # df -> num
  #
  # Input:
  #   - coln: df containing all the columns related to consent
  #
  # Get the pos of the patients who consented to participate in this study
  
  tmp <- NULL
  
  if (ncol(df) == 5){
    for (i in 1:nrow(df)){
      if (length(unique(unlist(unique(df[i,])))) > 1){
        if (is.na(df[i,1]) & is.na(df[i,2]) & is.na(df[i,3])){ # Old consent form format
          if (!(is.na(df[i,4])) & df[i,4] == "Yes"){
            tmp <- c(tmp, i)
          }
          
        }else{ # New consent form format
          if (!is.na(df[i,1]) & df[i,1] == "I have already read the full consent form and accept to respond to this survey"){
            tmp <- c(tmp, i)
          }else if (is.na(df[i,1]) & is.na(df[i,2]) & df[i,3] == "I do not wish to take this survey"){
            tmp <- tmp # Do not add
          }else if (is.na(df[i,1]) & df[i,2] == "I wish to read the full consent form before responding to this survey" & !(is.na(df[i,4])) & df[i,4] == "Yes"){
            tmp <- c(tmp, i)
          }
        }
      }
    }
  }else{
    for (i in 1:nrow(df)){
      if (!is.na(df[i,1]) & df[i,1] == "Yes"){
        tmp <- c(tmp, i)
      }
    }
  }
  return(tmp)
}

# Function 2
get_single_answer <- function(df){
  # df -> str
  # 
  # Input:
  #   - df: df containing the variables of interest
  #
  # Get the answers to the survey question when a single answer is possible.
  
  tmp <- NULL
  
  # Reformat "other"
  pos <- which(!is.na(df[,ncol(df)]))
  if (length(pos) > 0){
    df[pos,ncol(df)] <- str_to_title(gsub("Other \\(please specify\\) - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Or Another Group\\? Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other: Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other - ", "", df[pos,ncol(df)]))
  }
  
  for (i in 1:nrow(df)){
    if (length(as.character(na.omit(unique(unlist(df[i,]))))) == 1){
      tmp <- c(tmp, as.character(na.omit(unique(unlist(df[i,])))))
    }else{
      tmp <- c(tmp, "Missing/did not answer")
    }
  }
  return(tmp)
}

# Function 3
get_official_language <- function(all_languages, other_pos){
  # df -> str
  #
  # Input:
  #   - all_languages: data frame containing the preferred official languages (English or French) of all participants
  #   - other_pos: num vector containing the position of allophones
  #
  # Get the preferred official languages in allophones
  
  tmp <- NULL
  
  for (i in 1:nrow(all_languages)){
    # if (length(unique(unlist(all_languages[i,]))) == 1){
    #   tmp <- c(tmp, "Missing")
    # }else{
    #   tmp2 <- na.omit(as.character(unlist(all_languages[i,])))
    #   if (length(tmp2) > 1){
    #     tmp <- c(tmp, "Both")
    #   }else if (length(tmp2) == 1){
    #     tmp <- c(tmp, tmp2)
    #   }
    # }
    if (!(i %in% other_pos)){ # If NOT an allophone
      tmp <- c(tmp, NA)
    }else{
      if (length(unique(unlist(all_languages[i,]))) == 1){
        tmp <- c(tmp, "Missing/did not answer")
      }else{
        tmp2 <- na.omit(as.character(unlist(all_languages[i,])))
        if (length(tmp2) > 1){
          tmp <- c(tmp, "Both English and French")
        }else if (length(tmp2) == 1){
          tmp <- c(tmp, tmp2)
        }
      }
    }
  }
  return(tmp)
}

# Function 4
get_rural_urban <- function(three_digits_postalcode){
  # str -> str
  #
  # Input:
  #   - three_digits_postalcode: str vector containing the three first characters of the postal codes of all patients
  #
  # In Canada, the number of the Forward Sortation Area (FSA) indicates whether is it rural (0) or urban (1-9)
  # Returns if the postal code is rural or urban
  
  tmp <- NULL
  
  for (i in three_digits_postalcode){
    if (is.na(i)){
      tmp <- c(tmp, NA)
    }else{
      tmp2 <- as.numeric(strsplit(i, "")[[1]][2])
      if (tmp2 == 0){
        tmp <- c(tmp, "rural")
      }else{
        tmp <- c(tmp, "urban")
      }
    }
  }
  return(tmp)
}

# Function 5
get_free_text <- function(variable){
  # str -> str
  #
  # Input:
  #   - variable: str vector containing the variable of interest
  #
  # Get the answers to the survey question where free text is required
  
  tmp <- NULL
  
  if (length(variable) == 0){
    return("Missing/did not answer")
  }else{
    for (i in 1:length(variable)){
      if (!is.na(variable[i])){
        tmp <- c(tmp, variable[i])
      }else{
        tmp <- c(tmp, "Missing/did not answer")
      }
    }
  }
  return(tmp)
}

# Function 6
get_check_all <- function(df){
  # df -> str
  #
  # Input:
  #   - df: data frame containing the variables of interest
  #
  # Get the answers to the survey question where "check all that apply" is a possibility
  
  tmp <- NULL
  
  # Reformat "other"
  pos <- which(!is.na(df[,ncol(df)]))
  if (length(pos) > 0){
    df[pos,ncol(df)] <- str_to_title(gsub("Other \\(please specify\\) - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Or Another Group\\? Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other: Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other - ", "", df[pos,ncol(df)]))
  }
  
  for (i in 1:nrow(df)){
    tmp2 <- unique(unlist(df[i,]))
    if (length(as.character(na.omit(tmp2))) > 1){
      tmp <- c(tmp, paste0(as.character(as.character(na.omit(tmp2))), collapse = ", "))
    }else if (length(as.character(na.omit(tmp2))) == 1){
      tmp <- c(tmp, as.character(na.omit(tmp2)))
    }else{
      tmp <- c(tmp, "Missing/did not answer")
    }
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(readxl)
library(forstringr)
library(stringr)

# To modify
today <- "250402"
tool <- "Cliniconex"
filename <- "Survey 2 - Care coordination and social isolation 2.0.xlsx"
shortname <- "survey2.0_ACHH_consent"
longname <- "Survey 2 - Care coordination and social isolation for OHH evaluation 2.0"
data_dir <- "/Users/audreelemieux/Documents/CPIN Data Analysis/Raw data/Cliniconex"
output_dir <- "/Users/audreelemieux/Documents/CPIN Data Analysis/Analyzed data"

#################################################################################################
#################################################################################################

# Read data
raw <- as.data.frame(read_xlsx(paste0(data_dir, "/", filename)))
raw <- str_rm_whitespace_df(raw)

# Remove our "test" data
pos <- which(raw$Provider == "Sharon Johnston" | raw$Provider == "None")
if (length(pos) > 0){
  raw <- raw[-pos,]
}

##################################################

# Get all Providers for this study
Providers <- unique(raw$Provider[2:nrow(raw)])
Providers <- sort(Providers)

survey_data <- NULL
response_rate <- NULL
# tmp3 <- NULL
n <- 0

for (i in 1:length(Providers)){
  # Only select responses from the mentioned provider(s)
  data <- data.frame(raw[which(raw$Provider == Providers[i]),])
  
  # Only analyze the data of patients who consented
  coln <- grep("Your.primary.care.provider.is.participating", colnames(data))
  coln <- coln[1]
  if (length(coln) > 0){
    coln2 <- grep("accept.to.participate.in.this.study", colnames(data))
    pos <- get_consented_data(data[,c((coln:(coln + 2)), coln2, (coln2 + 1))]) # Which patient accepted to participate?
  }else{
    rm(coln) # Clean space
    coln2 <- grep("accept.to.participate.in.this.study", colnames(data))
    pos <- get_consented_data(data[,c(coln2, (coln2 + 1))]) # Which patient accepted to participate?
  }
  data_consented <- data[pos,]
  
  # Are there any duplicated responses?
  tmp <- table(data_consented$Patient.ID)
  if (length(which(tmp >= 2)) > 0){
    n <- n + 1
    if (n == 1){
      sink(paste0(output_dir, "/", today, "_DuplicatedAnswers.txt"), append = T) # Store in .txt file
      cat(paste0("\n\n--- Survey: ", longname, " ---"))
    }else{
      sink(paste0(output_dir, "/", today, "_DuplicatedAnswers.txt"), append = T)
    }
    cat(paste0("\n", Providers[i], ": ", names(which(tmp >= 2))))
    sink()
  }
  
  # Date completed
  date <- data_consented$End.Date
  date <- sapply(strsplit(date, " "), `[`, 1)
  
  ##################################################
  
  # Sociodemographic data of participants
  # Might change depending on the survey
  
  # Unique identifier
  ref_number <- data_consented$Patient.ID
  
  # Age
  age <- data_consented$Age
  
  # Sex
  sex <- data_consented$Gender
  
  # EMR Recorded Language
  EMR_lang <- data_consented$Languages
  
  # Get mother Tongue (single answer)
  coln <- grep("mother.tongue", colnames(data_consented))
  mother_tongue <- get_single_answer(data_consented[,(coln:(coln+2))])
  
  # For allophones: in which official language of Canada are you most comfortable receiving healthcare services? (check all that apply)
  other_pos <- setdiff(1:length(mother_tongue), which(mother_tongue == "English" | mother_tongue == "French" | mother_tongue == "English, French")) # Which are not French/Eng
  coln <- grep("In.what.official.language", colnames(data_consented))
  official_lang <- data_consented[,c(coln, coln + 1)]
  official_lang <- get_official_language(official_lang, other_pos)
  
  # Medical conditions
  med_cond <- data_consented$Medical.Conditions
  
  # Postal codes
  postal_codes <- data_consented$Postal.Code
  rural_urban <- get_rural_urban(postal_codes) # Get rural or urban
  
  ##################################################
  
  ### Survey answers ###
  
  # Was the health information we shared with you recently easy to understand? 
  coln <- grep("health.information.we.shared", colnames(data_consented))
  messages_understand <- get_single_answer(data_consented[,(coln:(coln + 4))])
  messages_understand <- gsub("[Vv]ery [eE]asy [Tt]o [Uu]nderstand", "", messages_understand)
  messages_understand <- gsub("[Nn]ot [Aa]t [Aa]ll [eE]asy [Tt]o [Uu]nderstand", "", messages_understand)
  messages_understand <- str_trim(messages_understand)
  
  # How valuable was the health information your primary care provider shared with you recently?
  coln <- grep("valuable.was.", colnames(data_consented))
  messages_value <- get_single_answer(data_consented[,(coln:(coln + 4))])
  messages_value <- gsub("Very [vV]aluable", "", messages_value)
  messages_value <- gsub("[nN]ot [vV]aluable", "", messages_value)
  messages_value <- str_trim(messages_value)
  
  # Will you or did you share with anyone else the information your primary care provider sent you?
  # coln <- grep("Will.you.or.", colnames(data_consented))
  coln <- grep("Will.you.share.", colnames(data_consented))
  share_info <- get_single_answer(data_consented[,(coln:(coln + 1))])
  
  # If "Yes" for previous question
  coln <- grep("How.many.people", colnames(data_consented))[2]
  yes_pos <- grep("^Yes", share_info)
  npeople_shared <- rep(NA, length(share_info))
  npeople_shared[yes_pos] <- get_free_text(data_consented[yes_pos, coln]) # How many people?

  # Please suggest topics or community resources that you would like more information about
  coln <- grep("Please.suggest", colnames(data_consented))
  resources_sugg <- get_free_text(data_consented[,coln])
  
  ##########
  
  # Have you received healthcare services from somewhere other than your family doctor or nurse practitioner’s office in the last 6 months?
  coln <- grep("Have.you.received.healthcare", colnames(data_consented))
  received_healthcare_other <- get_single_answer(data_consented[,(coln:(coln + 1))])
  
  # If "Yes" for previous question
  # Part 2 - Please indicate what services you received (check all)
  coln <- grep("indicate.what.services", colnames(data_consented))
  yes_pos <- grep("^Yes", received_healthcare_other)
  received_healthcare_other_2 <- rep(NA, length(received_healthcare_other))
  received_healthcare_other_2[yes_pos] <- get_check_all(data_consented[yes_pos,(coln:(coln + 3))])
  received_healthcare_other_2 <- gsub("Other Health Care Professional Such As A Dietician, Psychologist, Or Physiotherapist Please Indicate Which Type - ", "Other - ", received_healthcare_other_2)
  
  # Part 3 - In the last 6 months, how much did your family doctor or nurse help you get the healthcare
  # you need from other places?
  coln <- grep("how.much.did.your.family.doctor", colnames(data_consented))
  received_healthcare_other_3 <- rep(NA, length(received_healthcare_other))
  received_healthcare_other_3[yes_pos] <- get_single_answer(data_consented[yes_pos,(coln:(coln + 4))])
  
  # Part 4 - In the last 6 months, did you feel like the appointments with the whole healthcare team
  # (specialist, social service providers, and primary care providers) were well synchronized to offer you
  # the best possible care?
  coln <- grep("did.you.feel.like.the.appointments", colnames(data_consented))
  received_healthcare_other_4 <- rep(NA, length(received_healthcare_other))
  received_healthcare_other_4[yes_pos] <- get_single_answer(data_consented[yes_pos,(coln:(coln + 4))])
  
  # Part 5 - In the last 6 months, how much has the whole healthcare team (specialist, social service providers,
  # and primary care providers) provided smooth transitions from one service to another?
  coln <- grep("how.much.has.the.whole", colnames(data_consented))
  received_healthcare_other_5 <- rep(NA, length(received_healthcare_other))
  received_healthcare_other_5[yes_pos] <- get_single_answer(data_consented[yes_pos,(coln:(coln + 4))])
  
  ##########
  
  # If you needed it, how many people (family or friends) could help you with activities of daily living (e.g. dressing, driving)?
  coln <- grep("If.you.needed.it", colnames(data_consented))
  nfriends_family_daily <- get_single_answer(data_consented[,(coln:(coln + 2))])
  
  # How many people (family or friends) show you love and affection when you need it?
  coln <- grep("How.many.people", colnames(data_consented))
  coln <- coln[1]
  nfriends_family_love <- get_single_answer(data_consented[,(coln:(coln + 2))])
  
  ##################################################
  
  # Get the number of people who opened the survey, but did not answer anything
  unique_data <- list()
  tmp2 <- NULL
  for (j in 1:nrow(data_consented)){
    unique_data[[j]] <- unique(unlist(data_consented[j,(16:57)])) # 16:57 might have to be changed depending on the survey file
    if (length(as.character(na.omit(unique_data[[j]]))) == 0){
      tmp2 <- c(tmp2, j)
      # tmp3 <- c(tmp3, j)
    }
  }
  
  # Put in dataframe
  survey_data <- rbind(survey_data, cbind(
    tool = tool,
    survey_name = longname,
    date = date,
    # clinic = clinic,
    provider = Providers[i],
    ref_number = ref_number,
    age = age,
    sex = sex,
    emr_recorded_language = EMR_lang,
    n_medical_conditions = med_cond,
    postal_codes = postal_codes,
    rural_or_urban = rural_urban,
    mother_tongue = mother_tongue,
    allophones_preferred_language_Canada = official_lang,
    messages_understand = messages_understand,
    messages_value = messages_value,
    share_info = share_info,
    npeople_shared = npeople_shared,
    resources_sugg = resources_sugg,
    received_healthcare_other = received_healthcare_other,
    received_healthcare_other_2 = received_healthcare_other_2,
    received_healthcare_other_3 = received_healthcare_other_3,
    received_healthcare_other_4 = received_healthcare_other_4,
    received_healthcare_other_5 = received_healthcare_other_5,
    nfriends_family_daily = nfriends_family_daily,
    nfriends_family_love = nfriends_family_love
  ))
  
  response_rate <- rbind(response_rate, cbind(
    tool = tool,
    survey_name = longname,
    provider = Providers[i],
    n_sent = NA,
    n_undelivered = NA,
    n_responded = nrow(data),
    n_consented = nrow(data_consented),
    n_opened_but_no_answer = length(tmp2)
  ))
  
  rm(data, data_consented, age, coln2, EMR_lang, sex, med_cond, pos, postal_codes, rural_urban, messages_understand,
     messages_value, share_info, npeople_shared, resources_sugg, received_healthcare_other,
     received_healthcare_other_2, received_healthcare_other_3, received_healthcare_other_4,received_healthcare_other_5,
     nfriends_family_daily, nfriends_family_love) # Clean space
}
survey_data <- as.data.frame(survey_data)
response_rate <- as.data.frame(response_rate)

# Export as CSV
write.table(survey_data, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_data.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")
write.table(response_rate, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_responserate.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
