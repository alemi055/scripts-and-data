
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 25, 2025
# V2

#################################################################################################

                                    #####################
                                    # Declare functions #
                                    #####################

# Function 1
NA_missing <- function(values){
  # str or num -> str or num
  #
  # Input:
  #   - values: str or num vector containing the values of interest
  #
  # Replace the "NAs" by "Missing/did not answer"
  
  tmp <- values
  NA_pos <- which(is.na(values) | values == "")
  
  if (length(NA_pos) > 0){
    tmp[NA_pos] <- "Missing/did not answer"
  }
  return(tmp)
}

# Function 2
get_rural_urban <- function(three_digits_postalcode){
  # str -> str
  #
  # Input:
  #   - three_digits_postalcode: str vector containing the three first characters of the postal codes of all patients
  #
  # In Canada, the number of the Forward Sortation Area (FSA) indicates whether is it rural (0) or urban (1-9)
  # Returns if the postal code is rural or urban
  
  tmp <- NULL
  
  for (i in three_digits_postalcode){
    if (is.na(i)){
      tmp <- c(tmp, NA)
    }else{
      tmp2 <- as.numeric(strsplit(i, "")[[1]][2])
      if (tmp2 == 0){
        tmp <- c(tmp, "rural")
      }else{
        tmp <- c(tmp, "urban")
      }
    }
  }
  return(tmp)
}

# Function 3
get_check_all <- function(df){
  # df -> str
  #
  # Input:
  #   - df: data frame containing the variables of interest
  #
  # Get the answers to the survey question where "check all that apply" is a possibility
  
  tmp <- NULL
  
  # Reformat "other"
  pos <- which(!is.na(df[,ncol(df)]))
  if (length(pos) > 0){
    df[pos,ncol(df)] <- str_to_title(gsub("Other \\(please specify\\) - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Or Another Group\\? Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other: Please Specify - ", "", df[pos,ncol(df)]))
    df[pos,ncol(df)] <- str_to_title(gsub("Other - ", "", df[pos,ncol(df)]))
  }
  
  for (i in 1:nrow(df)){
    tmp2 <- unique(unlist(df[i,]))
    if (length(as.character(na.omit(tmp2))) > 1){
      tmp <- c(tmp, paste0(as.character(as.character(na.omit(tmp2))), collapse = ", "))
    }else if (length(as.character(na.omit(tmp2))) == 1){
      tmp <- c(tmp, as.character(na.omit(tmp2)))
    }else{
      tmp <- c(tmp, "Missing/did not answer")
    }
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(readxl)
library(forstringr)
library(stringr)
library(lubridate)

# To modify
today <- "250425"
tool <- "Qualtrics"
filename <- "ACHH Survey 2 - Care coordination and social isolation_April 4, 2025_16.23.csv"
filename_ICES <- "St-Isidore CPIN ICES.xlsx"
date_sent <- "2025-03-05"
shortname <- "survey2.0_ACHH_consent"
longname <- "Survey 2 - Care coordination and social isolation for OHH evaluation 2.0"
data_dir <- "/Users/audreelemieux/Documents/CPIN Data Analysis/Raw data/Qualtrics"
output_dir <- "/Users/audreelemieux/Documents/CPIN Data Analysis/Analyzed data"

#################################################################################################
#################################################################################################

# Read data
raw <- as.data.frame(read.csv(paste0(data_dir, "/CSV/", filename)))
raw <- str_rm_whitespace_df(raw)
colnames(raw) <- raw[1,]
raw <- raw[-(1:2),]

# Remove our "test" data
pos <- which(raw$PatientDoctor_MDName == "Sharon Johnston" | is.na(raw$PatientDoctor_MDName) | raw$PatientDoctor_MDName == "")
if (length(pos) > 0){
  data <- raw[-pos,]
}

# Only analyze the data of patients who consented
coln <- grep("^Your primary care provider is participating", colnames(data))
coln2 <- grep("PARTICIPANT INFORMED CONSENT FORM", colnames(data))
data_consented <- data[which(data[,coln] == "I have already read the full consent form and accept to respond to this survey"),] # Have already consented
data_consented <- rbind(data_consented, data[which(data[,coln] ==  "I wish to read the full consent form before responding to this survey" & # Wanted to read the full form
                                                     data[,coln2] == "Yes"),])
rm(coln, coln2) # Clean space

##################################################

# Are there any duplicated responses?
tmp <- table(data_consented$PatientChartNumber)
n <- 0
Providers <- sort(unique(data_consented$PatientDoctor_MDName))

for (i in 1:length(Providers)){
  if (length(which(tmp >= 2)) > 0){
    n <- n + 1
    if (n == 1){
      sink(paste0(output_dir, "/", today, "_DuplicatedAnswers.txt")) # Store in .txt file
      cat(paste0("--- Survey: ", longname, " (Qualtrics) ---"))
    }else{
      sink(paste0(output_dir, "/", today, "_DuplicatedAnswers.txt"), append = T)
    }
    cat(paste0("\n", Providers[i], ": ", names(which(tmp >= 2))))
    sink()
  }
}

##################################################

# Sociodemographic data of participants
# Might change depending on the survey

# Age
data_consented$age <- floor(time_length(difftime(as.Date(date_sent), as.Date(data_consented$Birthdate)), unit = "years"))
age <- data_consented$age

# Date completed
date <- as.character(as_datetime(data_consented$`End Date`))
date <- sapply(strsplit(date, " "), `[`, 1)

# Sex
sex <- data_consented$Sex
sex <- gsub("M", "Male", sex)
sex <- gsub("F", "Female", sex)

# EMR Recorded Language
coln <- grep("emr_recorded_language", colnames(data_consented))
EMR_lang <- data_consented[,coln]
EMR_lang <- gsub("EN", "English", EMR_lang)
EMR_lang <- gsub("FR-CA", "French", EMR_lang)
rm(coln) # Clean space

# Mother Tongue
coln <- grep("mother.tongue", colnames(data_consented))
mother_tongue <- NA_missing(data_consented[,coln])
rm(coln) # Clean space

# In what language are allophones most comfortable receiving healthcare services with?
official_lang <- rep(NA, nrow(data_consented))
other_pos <- which(mother_tongue == "Other")
coln <- grep("In what official language", colnames(data_consented))
official_lang[other_pos] <- data_consented[other_pos,coln]
official_lang[other_pos] <- gsub("English,French", "Both English and French", official_lang[other_pos])
rm(other_pos, coln) # Clean space

# Get medical conditions
med_cond <- data_consented$NumberOfMedications

# Postal codes
postal_codes <- substr(data_consented$PostalCode, 1, 3)
postal_codes[which(postal_codes == "")] <- NA
rural_urban <- get_rural_urban(postal_codes) # Get rural or urban

##################################################

### Survey answers ###

# Was the health information we shared with you recently easy to understand? 
coln <- grep("health.information.we.shared", colnames(data_consented))
messages_understand <- NA_missing(data_consented[,coln])
messages_understand <- gsub("[Vv]ery [eE]asy [Tt]o [Uu]nderstand", "", messages_understand)
messages_understand <- gsub("[Nn]ot [Aa]t [Aa]ll [eE]asy [Tt]o [Uu]nderstand", "", messages_understand)
messages_understand <- str_trim(messages_understand)

# How valuable was the health information your primary care provider shared with you recently?
coln <- grep("valuable.was.", colnames(data_consented))
messages_value <- NA_missing(data_consented[,coln])
messages_value <- gsub("Very [vV]aluable", "", messages_value)
messages_value <- gsub("[nN]ot [vV]aluable", "", messages_value)
messages_value <- str_trim(messages_value)

# Will you or did you share with anyone else the information your primary care provider sent you?
# coln <- grep("Will.you.or.", colnames(data_consented))
coln <- grep("Will.you.share.", colnames(data_consented))
share_info <- NA_missing(data_consented[,coln])

# If "Yes" for previous question
coln <- grep("How.many.people", colnames(data_consented))[2]
yes_pos <- grep("^Yes", share_info)
npeople_shared <- rep(NA, length(share_info))
npeople_shared[yes_pos] <- NA_missing(data_consented[yes_pos,coln])

# Please suggest topics or community resources that you would like more information about
coln <- grep("Please.suggest", colnames(data_consented))
resources_sugg <- NA_missing(data_consented[,coln])

##########

# Have you received healthcare services from somewhere other than your family doctor or nurse practitioner’s office in the last 6 months?
coln <- grep("Have.you.received.healthcare", colnames(data_consented))
received_healthcare_other <- NA_missing(data_consented[,coln])

# If "Yes" for previous question
# Part 2 - Please indicate what services you received (check all)
coln <- grep("indicate.what.services", colnames(data_consented))
yes_pos <- grep("^Yes", received_healthcare_other)
received_healthcare_other_2 <- rep(NA, length(received_healthcare_other))
received_healthcare_other_2[yes_pos] <- NA_missing(get_check_all(data_consented[yes_pos,coln]))
received_healthcare_other_2 <- gsub("Other health care professional such as a dietician, psychologist, or physiotherapist. Please indicate which type, ", "Other - ", received_healthcare_other_2)
received_healthcare_other_2 <- gsub(" ,", ", ", received_healthcare_other_2)
received_healthcare_other_2 <- gsub(", $", "", received_healthcare_other_2)

# Part 3 - In the last 6 months, how much did your family doctor or nurse help you get the healthcare
# you need from other places?
coln <- grep("how.much.did.your.family.doctor", colnames(data_consented))
received_healthcare_other_3 <- rep(NA, length(received_healthcare_other))
received_healthcare_other_3[yes_pos] <- NA_missing(data_consented[yes_pos,coln])

# Part 4 - In the last 6 months, did you feel like the appointments with the whole healthcare team
# (specialist, social service providers, and primary care providers) were well synchronized to offer you
# the best possible care?
coln <- grep("did.you.feel.like.the.appointments", colnames(data_consented))
received_healthcare_other_4 <- rep(NA, length(received_healthcare_other))
received_healthcare_other_4[yes_pos] <- NA_missing(data_consented[yes_pos,coln])

# Part 5 - In the last 6 months, how much has the whole healthcare team (specialist, social service providers,
# and primary care providers) provided smooth transitions from one service to another?
coln <- grep("how.much.has.the.whole", colnames(data_consented))
received_healthcare_other_5 <- rep(NA, length(received_healthcare_other))
received_healthcare_other_5[yes_pos] <- NA_missing(data_consented[yes_pos,coln])

##########

# If you needed it, how many people (family or friends) could help you with activities of daily living (e.g. dressing, driving)?
coln <- grep("If.you.needed.it", colnames(data_consented))
nfriends_family_daily <- NA_missing(data_consented[,coln])

# How many people (family or friends) show you love and affection when you need it?
coln <- grep("How.many.people", colnames(data_consented))
coln <- coln[1]
nfriends_family_love <- NA_missing(data_consented[,coln])

##################################################

# Put in dataframe
survey_data <- cbind(
  tool = tool,
  survey_name = longname,
  date = date,
  provider = data_consented$PatientDoctor_MDName,
  ref_number = data_consented$ExternalDataReference,
  age = age,
  sex = sex,
  emr_recorded_language = EMR_lang,
  n_medical_conditions = med_cond,
  postal_codes = postal_codes,
  rural_or_urban = rural_urban,
  mother_tongue = mother_tongue,
  allophones_preferred_language_Canada = official_lang,
  messages_understand = messages_understand,
  messages_value = messages_value,
  share_info = share_info,
  npeople_shared = npeople_shared,
  resources_sugg = resources_sugg,
  received_healthcare_other = received_healthcare_other,
  received_healthcare_other_2 = received_healthcare_other_2,
  received_healthcare_other_3 = received_healthcare_other_3,
  received_healthcare_other_4 = received_healthcare_other_4,
  received_healthcare_other_5 = received_healthcare_other_5,
  nfriends_family_daily = nfriends_family_daily,
  nfriends_family_love = nfriends_family_love
)

##########

Providers <- sort(unique(data$PatientDoctor_MDName))
response_rate <- NULL

for (i in 1:length(Providers)){
  data_tmp <- data[which(data$PatientDoctor_MDName == Providers[i]),]
  data_consented_tmp <- data_consented[which(data_consented$PatientDoctor_MDName == Providers[i]),]
  
  # Get the number of people who opened the survey, but did not answer anything
  unique_data <- list()
  tmp2 <- NULL
  for (j in 1:nrow(data_consented_tmp)){
    unique_data[[j]] <- unique(unlist(data_consented_tmp[j,(12:19)])) # 12:19 might have to be changed depending on the survey file
    if (length(as.character(na.omit(unique_data[[j]]))) == 0){
      tmp2 <- c(tmp2, j)
      # tmp3 <- c(tmp3, j)
    }
  }
  
  response_rate <- rbind(response_rate, cbind(
    tool = tool,
    survey_name = gsub(".xlsx", "", filename),
    provider = Providers[i],
    n_sent = NA,
    n_undelivered = NA,
    n_responded = nrow(data_tmp),
    n_consented = nrow(data_consented_tmp),
    n_opened_but_no_answer = length(tmp2)
  ))
  
}

rm(data, data_consented, age, coln2, EMR_lang, sex, med_cond, pos, postal_codes, rural_urban, messages_understand,
   messages_value, share_info, npeople_shared, resources_sugg, received_healthcare_other,
   received_healthcare_other_2, received_healthcare_other_3, received_healthcare_other_4,received_healthcare_other_5,
   nfriends_family_daily, nfriends_family_love) # Clean space

survey_data <- as.data.frame(survey_data)
response_rate <- as.data.frame(response_rate)

# Export as CSV
write.table(survey_data, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_data.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")
write.table(response_rate, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_responserate.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
