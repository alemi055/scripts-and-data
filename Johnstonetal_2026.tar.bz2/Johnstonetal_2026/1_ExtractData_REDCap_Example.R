
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on April 14, 2025
# V4

#################################################################################################

                                    #####################
                                    # Declare functions #
                                    #####################

# Function 1
NA_missing <- function(values){
  # str or num -> str or num
  #
  # Input:
  #   - values: str or num vector containing the values of interest
  #
  # Replace the "NAs" by "Missing/did not answer"
  
  tmp <- values
  NA_pos <- which(is.na(values) | values == "")
  
  if (length(NA_pos) > 0){
    tmp[NA_pos] <- "Missing/did not answer"
  }
  return(tmp)
}

# Function 2
get_checked_all <- function(df){
  data <- NULL
  row_names <- NULL
  for (i in 1:ncol(df)){
    tmp <- strsplit(colnames(df)[i], "\\(choice=")[[1]][2]
    tmp <- gsub("\\)", "", tmp)
    row_names <- c(row_names, tmp)
  }
  rm(i, tmp)
  
  for (i in 1:nrow(df)){
    pos <- which(df[i,] == "Checked")
    if (length(pos) > 0){
      data <- c(data, paste0(row_names[pos], collapse = ", "))
    }else{
      data <- c(data, "Missing/did not answer")
    }
  }
  return(data)
}

# Function 3
get_rural_urban <- function(three_digits_postalcode){
  # str -> str
  #
  # Input:
  #   - three_digits_postalcode: str vector containing the three first characters of the postal codes of all patients
  #
  # In Canada <- the number of the Forward Sortation Area (FSA) indicates whether is it rural (0) or urban (1-9)
  # Returns if the postal code is rural or urban

  tmp <- NULL

  for (i in three_digits_postalcode){
    if (is.na(i)){
      tmp <- c(tmp, NA)
    }else{
      tmp2 <- as.numeric(strsplit(i, "")[[1]][2])
      if (tmp2 == 0){
        tmp <- c(tmp, "rural")
      }else{
        tmp <- c(tmp, "urban")
      }
    }
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(readxl)
library(forstringr)
library(stringr)

# To modify
today <- "250414"
tool <- "REDCap"
filename <- "CPIN Umbrella Study Introduction Survey_BAFHT.csv"
shortname <- "CPINUmbrellaIntro_BAFHT"
longname <- "CPIN Umbrella Introduction Survey"
data_dir <- "/Users/audreelemieux/Documents/Institut du Savoir Montfort/CPIN Data Analysis/Raw data/REDCap/CSV"
output_dir <- "/Users/audreelemieux/Documents/Institut du Savoir Montfort/CPIN Data Analysis/Analyzed data"

#################################################################################################
#################################################################################################

# Read data
raw <- as.data.frame(read.table(paste0(data_dir, "/", filename), sep = ";"))
raw <- str_rm_whitespace_df(raw)
colnames(raw) <- raw[1,]
raw <- raw[-1,]

survey_data <- NULL
response_rate <- NULL

# Do we look at both EN and FR?
coln <- grep("language of survey", colnames(raw))
survey_lang_EN <- which(raw[,coln] == "English")
survey_lang_FR <- which(raw[,coln] == "Français")

#################################################################################################

# Identify columns of interest
# Create a df
coln_df <- NULL
coln_gender <- grep("What is your gender", colnames(raw))
coln_spokenathome <- grep("at home", colnames(raw))
coln_allophone_officiallang <- grep("healthcare services", colnames(raw))
coln_level_EN_FR <- grep("How well", colnames(raw))
coln_written_info <- grep("written", colnames(raw))
coln_education <- grep("education", colnames(raw))
coln_education <- c(coln_education, coln_education[length(coln_education)] + 1)
coln_racial_group <- grep("racial", colnames(raw))
coln_racial_group <- c(coln_racial_group, coln_racial_group[length(coln_racial_group)] + 1)
coln_message_understand <- grep("easy to understand", colnames(raw))
coln_message_value <- grep("valuable", colnames(raw))
coln_topics <- grep("topics", colnames(raw))
coln_share <- grep("share this health", colnames(raw))
coln_npeople <- grep("many people", colnames(raw))
coln_source <- grep("^Your family", colnames(raw)):(grep("^Your family", colnames(raw)) + 10)
coln_age <- grep("What is your age", colnames(raw))
coln_postalcode <- grep("your postal code", colnames(raw))

coln_df <- cbind(coln_df, rbind(
  gender = coln_gender,
  spokenathome = paste0(coln_spokenathome, collapse = ", "),
  allophone_officiallang = coln_allophone_officiallang,
  level_EN_FR = paste0(coln_level_EN_FR, collapse = ", "),
  written_info = coln_written_info,
  education = paste0(coln_education, collapse = ", "),
  racial_group = paste0(coln_racial_group, collapse = ", "),
  message_understand = coln_message_understand,
  message_value = coln_message_value,
  topics = coln_topics,
  share = coln_share,
  npeople = coln_npeople,
  source = paste0(coln_source, collapse = ", "),
  age = coln_age,
  postalcode = coln_postalcode
))

coln_gender <- grep("Quel est votre genre", colnames(raw))
coln_spokenathome <- grep("la maison", colnames(raw))
coln_allophone_officiallang <- grep("services médicaux", colnames(raw))
coln_level_EN_FR <- grep("facilité", colnames(raw))
coln_written_info <- grep("sur papier", colnames(raw))
coln_education <- grep("scolarité", colnames(raw))
coln_education <- c(coln_education, coln_education[length(coln_education)] + 1)
coln_racial_group <- grep("raciaux", colnames(raw))
coln_racial_group <- c(coln_racial_group, coln_racial_group[length(coln_racial_group)] + 1)
coln_message_understand <- grep("facile", colnames(raw))
coln_message_value <- grep("elles utiles", colnames(raw))
coln_topics <- grep("sujet", colnames(raw))
coln_share <- grep("partage", colnames(raw))
coln_npeople <- grep("combien de personnes", colnames(raw))
coln_source <- grep("^Votre médecin", colnames(raw)):(grep("^Votre médecin", colnames(raw)) + 10)
coln_age <- grep("votre âge", colnames(raw))
coln_postalcode <- grep("votre code postal", colnames(raw))

coln_df <- cbind(coln_df, rbind(
  gender = coln_gender,
  spokenathome = paste0(coln_spokenathome, collapse = ", "),
  allophone_officiallang = coln_allophone_officiallang,
  level_EN_FR = paste0(coln_level_EN_FR, collapse = ", "),
  written_info = coln_written_info,
  education = paste0(coln_education, collapse = ", "),
  racial_group = paste0(coln_racial_group, collapse = ", "),
  message_understand = coln_message_understand,
  message_value = coln_message_value,
  topics = coln_topics,
  share = coln_share,
  npeople = coln_npeople,
  source = paste0(coln_source, collapse = ", "),
  age = coln_age,
  postalcode = coln_postalcode
))
colnames(coln_df) <- c("English", "French")
coln_df <- as.data.frame(coln_df)
rm(coln_gender, coln_spokenathome, coln_allophone_officiallang, coln_written_info, coln_education, coln_racial_group,
   coln_message_understand, coln_message_value, coln_topics, coln_share, coln_npeople, coln_source, coln_level_EN_FR) # Clean space

#################################################################################################

data <- NULL
data_consented <- NULL

for (i in 1:2){
  if (i == 1 & length(survey_lang_EN) > 0){ # English
    data[[i]] <- raw[survey_lang_EN,]
    
    # Over 18 years old?
    coln <- grep("18 years old", colnames(data[[i]]))
    pos <- which(data[[i]][,coln] != "Yes")
    if (length(pos) > 0){
      data[[i]] <- data[[i]][-pos,]
    }
    
    # Consent
    coln <- grep("^IntroductionYour", colnames(data[[i]]))
    coln2 <- grep("PARTICIPANT INFORMED", colnames(data[[i]]))
    pos <- which(data[[i]][,coln] == "I read the full consent form and agree to take this survey")
    pos <- c(pos, which(data[[i]][,coln] == "I want to read the full consent form before agreeing to take this survey" & data[[i]][,coln2] == "Yes"))
    data_consented[[i]] <- data[[i]][pos,]
  }else if (i == 2 & length(survey_lang_FR) > 0){
    data[[i]] <- raw[survey_lang_FR,]
    
    # Over 18 years old?
    coln <- grep("18 ans", colnames(data[[i]]))
    pos <- which(data[[i]][,coln] != "Yes")
    if (length(pos) > 0){
      data[[i]] <- data[[i]][-pos,]
    }
    
    # Consent
    coln <- grep("^Introduction Votre", colnames(data[[i]]))
    coln2 <- grep("FORMULAIRE DE", colnames(data[[i]]))
    pos <- which(data[[i]][,coln] == "J'ai déjà lu le formulaire de consentement complet et j'accepte de répondre à ce sondage.")
    pos <- c(pos, which(data[[i]][,coln] == "Je souhaite lire le formulaire de consentement complet avant de répondre à ce sondage." & data[[i]][,coln2] == "Yes"))
    data_consented[[i]] <- data[[i]][pos,]
  }
}

#################################################################################################

# Translate
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Femme", "Woman", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Homme", "Man", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Autre", "Other", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Anglais", "English", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Français", "French", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Non", "No", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Oui", "Yes", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Très faciles à comprendre", "Very easy to understand", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Pas du tout faciles à comprendre", "Not all all easy to understand", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Très utiles", "Very valuable", x)}))
# data_consented[[2]] <- lapply(data_consented[[2]], function(x){gsub("Très utiles", "Very valuable", x)}) #1 ???
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("9e à 12e année", "Grade 9 to 12", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai fait des études collégiales ou universitaires partielles", "I went to college or university but didn't get my degree", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai un diplôme d'études collégiales ou universitaires", "I have a college or university degree", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai un diplôme professionnel supérieur ou postuniversitaire (maîtrise, doctorat, médecin, avocat, etc.) ", "I have an advanced professional or postgraduate degree (Masters, PhD, physician, lawyer, etc.)", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Non", "No", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Oui", "Yes", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Très faciles à comprendre", "Very easy to understand", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Pas du tout faciles à comprendre", "Not all all easy to understand", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Très utiles", "Very valuable", x)}))
# data_consented[[2]] <- lapply(data_consented[[2]], function(x){gsub("Très utiles", "Very valuable", x)}) #1 ???
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("9e à 12e année", "Grade 9 to 12", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai fait des études collégiales ou universitaires partielles", "I went to college or university but didn't get my degree", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai un diplôme d'études collégiales ou universitaires", "I have a college or university degree", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("J'ai un diplôme professionnel supérieur ou postuniversitaire (maîtrise, doctorat, médecin, avocat, etc.) ", "I have an advanced professional or postgraduate degree (Masters, PhD, physician, lawyer, etc.)", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Extrêmement utile", "Extremely helpful", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Très utile", "Very helpful", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Plus ou moins utile", "Somewhat helpful", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Pas très utile", "Not so helpful", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Pas utile du tout", "Not at all helpful", x)}))
data_consented[[2]] <- as.data.frame(lapply(data_consented[[2]], function(x){gsub("Sans objet", "Not Applicable", x)}))
colnames(data_consented[[2]]) <- colnames(raw)

#################################################################################################

# Initialize all variables
sr_gender <- most_spoken_home <- official_lang <- preferred_lang_written <- level_EN_FR <- education_level <- racial_group <- NULL
messages_understand <- messages_value <- share_info <- npeople_shared <- resources_sugg <- resources_sugg <- source_fd <- NULL
source_pharmacist <- source_family <- source_gvt <- source_localph <- source_radio <- source_tv <- source_newspapers <- NULL
source_social <- source_other <- age <- postal_codes <- rural_urban <- date <- NULL

for (i in 1:2){ # i: language
  # # Sociodemographic data_consented of participants
  # Might change depending on the survey
  
  # Age
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[14,i])])
  age <- c(age, tmp)
  
  # Date
  coln <- grep("Timestamp", colnames(data_consented[[i]]))
  tmp <- as.character(unlist(sapply(strsplit(data_consented[[i]][,coln], " "), `[`, 1)))
  pos <- grep("not", tmp)
  if (length(pos) > 0){
    tmp[pos] <- NA
  }
  date <- c(date, as.character(tmp))
  
  # Get self-reported gender
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[1,i])])
  sr_gender <- c(sr_gender, tmp)
  
  # # Get most spoken language at home
  tmp <- data_consented[[i]][,as.numeric(strsplit(coln_df[2,i], ", ")[[1]])]
  tmp <- get_checked_all(tmp)
  if (i == 2){
    tmp <- gsub("Anglais", "English", tmp)
    tmp <- gsub("Français", "French", tmp)
    tmp <- gsub("Autre", "Other", tmp)
  }
  most_spoken_home <- c(most_spoken_home, tmp)
  
  # In which official language of Canada are you most comfortable receiving healthcare services? (only allophones or Missing)
  other_pos <- setdiff(1:length(tmp), which(tmp == "English" | tmp == "French" | tmp == "English, French")) # Which are not French/Eng
  tmp <- rep(NA, nrow(data_consented[[i]]))
  tmp[other_pos] <- NA_missing(data_consented[[i]][other_pos,as.numeric(coln_df[3,i])])
  official_lang <- c(official_lang, tmp)
  
  # What is your level of French or English (only allophones or Missing)
  tmp <- rep(NA, nrow(data_consented[[i]]))
  tmp2 <- data_consented[[i]][other_pos,as.numeric(strsplit(coln_df[4,i], ", ")[[1]])]
  tmp3 <- rep("Missing/did not answer", nrow(tmp2))
  pos <- which(tmp2[,1] != "")
  if (length(pos) > 0){
    tmp3[pos] <- tmp2[pos, 1]
  }
  pos <- which(tmp2[,2] != "")
  if (length(pos) > 0){
    tmp3[pos] <- tmp2[pos, 2]
  }
  tmp[other_pos] <- tmp3
  level_EN_FR <- c(level_EN_FR, tmp)
  rm(tmp, tmp2, tmp3, pos) # Clean space
  
  # What is your preferred language for written healthcare information?
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[5,i])])
  preferred_lang_written <- c(preferred_lang_written, tmp)

  # Postal codes
  tmp <- data_consented[[i]][,as.numeric(coln_df[15,i])]
  tmp <- str_to_upper(substr(tmp, 1, 3))
  tmp <- gsub("!", "1", tmp)
  tmp <- gsub("413", NA, tmp)
  tmp <- gsub("125", NA, tmp)
  tmp <- gsub("145", NA, tmp)
  tmp <- gsub("0K7", NA, tmp)
  tmp <- gsub("KIM", "K1M", tmp)
  tmp <- gsub("PRE", NA, tmp)
  tmp <- gsub("KIS", "K1S", tmp)
  tmp <- gsub("KPP", NA, tmp)
  tmp <- gsub("KIC", "K1C", tmp)
  tmp <- gsub("3J1", NA, tmp)
  tmp <- gsub("7G9", NA, tmp)
  tmp <- gsub("KIN", "K1N", tmp)
  tmp <- gsub("2L7", NA, tmp)
  tmp <- gsub("KOA", "K0A", tmp)
  tmp <- gsub("7M7", NA, tmp)
  tmp <- gsub("613", NA, tmp)
  tmp <- gsub("128", NA, tmp)
  postal_codes <- c(postal_codes, tmp)
  
  # Rural or urban
  pos <- which(tmp == "")
  if (length(pos) > 0){
    tmp[pos] <- NA
  }
  tmp2 <- get_rural_urban(tmp)
  rural_urban <- c(rural_urban, tmp2)
  
  # Get education level
  tmp2 <- data_consented[[i]][,as.numeric(strsplit(coln_df[6,i], ", ")[[1]])]
  tmp <- tmp2[,1]
  pos <- which(tmp2[,2] != "")
  if (length(pos) > 0){
    tmp[pos] <- paste0(tmp2[pos,1], " - ", tmp2[pos, 2])
  }
  tmp <- gsub("Other - ", "", tmp)
  education_level <- c(education_level, tmp)
  
  # Get racial group
  tmp2 <- data_consented[[i]][,as.numeric(strsplit(coln_df[7,i], ", ")[[1]])]
  tmp <- get_checked_all(tmp2[,c(1:(ncol(tmp2) - 1))])
  tmp <- gsub("etc.", "etc.)", tmp)
  tmp <- gsub("Inuit", "Inuit)", tmp)
  pos <- which(tmp2[,ncol(tmp2)] != "")
  if (length(pos) > 0){
    tmp[pos] <- paste0(tmp[pos], " ", tmp2[pos,ncol(tmp2)])
  }
  tmp <- gsub("Another group: ", "", tmp)
  if (i == 2){
    tmp <- gsub("Moyen-Orient ou Afrique du Nord \\(libanais, algérien, irakien, syrien, etc.\\)", "Middle Eastern or North African (Lebanese, Algerian, Iraqi, Syrian, etc.)", tmp)
    tmp <- gsub("Noir \\(afro-canadien, antillais, dorigine africaine, etc.\\)", "Black (African Canadian, Caribbean, African origin, etc.)", tmp)
    tmp <- gsub("Asie de lEst \\(Chine, Hong Kong, Japon, Corée du Nord, Corée du Sud, etc.\\)", "East Asian (China, Hong Kong, Japan, North Korea, South Korea, etc.)", tmp)
    tmp <- gsub("Autochtone \\(Premières Nations, Métis ou Inuit\\)", "Indigenous (First Nations, Métis or Inuit)", tmp)
    tmp <- gsub("Amérique latine \\(Mexique, Haïti, Uruguay, etc.\\)", "Latin American (Mexico, Haiti, Uruguay, etc.)", tmp)
    tmp <- gsub("Asie du Sud \\(indien de lEst, sri lankais, etc.\\)", "South Asian (East Indian, Sri Lankan, etc.)", tmp)
    tmp <- gsub("Asie du Sud-Est \\(Vietnamien, Cambodgien, etc.\\)", "South-East Asian (Vietnamese, Cambodian, etc.)", tmp)
    tmp <- gsub("Asie de lOuest \\(iranien, afghan, etc.\\)", "West Asian (Iranian, Afghan, etc.)", tmp)
    tmp <- gsub("Blanc/Caucasien", "White/Caucasian", tmp)
    tmp <- gsub("Préfère ne pas le dire", "Prefer not to say", tmp)
    tmp <- gsub("Autre groupe", "Another group:", tmp)
  }
  racial_group <- c(racial_group, tmp)
  rm(pos, tmp2) # Clean space
  
  ##################################################
  
  ### Survey answers ###
  
  # Was the health information we shared with you recently easy to understand?
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[8,i])])
  tmp <- gsub(" - [Vv]ery [eE]asy [Tt]o [Uu]nderstand", "", tmp)
  tmp <- gsub(" - Not all all easy to understand", "", tmp)
  messages_understand <- c(messages_understand, tmp)
  
  # How valuable was the health information your primary care provider shared with you recently?
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[9,i])])
  tmp <- gsub(" - Very valuable", "", tmp)
  tmp <- gsub(" - Not valuable", "", tmp)
  messages_value <- c(messages_value, tmp)
  
  # Will you or did you share with anyone else the information your primary care provider sent you?
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[11,i])])
  share_info <- c(share_info, tmp)
  
  # If "Yes" for previous question
  yes_pos <- grep("^Yes", tmp)
  tmp <- rep(NA, nrow(data_consented[[i]]))
  tmp[yes_pos] <- NA_missing(data_consented[[i]][yes_pos,as.numeric(coln_df[12,i])])
  npeople_shared <- c(npeople_shared, tmp)
  
  # Please suggest topics or community resources that you would like more information about
  tmp <- NA_missing(data_consented[[i]][,as.numeric(coln_df[10,i])])
  resources_sugg <- c(resources_sugg, tmp)
  
  ##########
  
  # In the table below <- please tell us about the sources of information which help you make decisions about your health or healthcare.
  tmp <- data_consented[[i]][,as.numeric(strsplit(coln_df[13,i], ", ")[[1]])]
  source_fd <- c(source_fd, NA_missing(tmp[,1])) # Your family doctor <- pediatrician or nurse
  source_pharmacist <- c(source_pharmacist, NA_missing(tmp[,2])) # Your pharmacist
  source_family <- c(source_family, NA_missing(tmp[,3])) # Family members or friends
  source_gvt <- c(source_gvt, NA_missing(tmp[,4])) # Provincial or federal government messages
  source_localph <- c(source_localph, NA_missing(tmp[,5])) # Local public health messages
  source_radio <- c(source_radio, NA_missing(tmp[,6])) # Radio
  source_tv <- c(source_tv, NA_missing(tmp[,7])) # TV
  source_newspapers <- c(source_newspapers, NA_missing(tmp[,8])) # Newspapers
  source_social <- c(source_social, NA_missing(tmp[,9])) # Social media: Facebook <- X (formerly Twitter) <- etc.
  
  tmp2 <- NA_missing(tmp[,10])
  pos <- which(tmp[,11] != "")
  if (length(pos) > 0){
    tmp2[pos] <- paste0(tmp2[pos], ", ", tmp[pos,11])
  }
  source_other <- c(source_other, tmp2)
}
rm(tmp, coln, coln2, pos, tmp2, yes_pos, other_pos) # Clean space

#################################################################################################

# Combine EN and FR
data[[3]] <- rbind(data[[1]], data[[2]])
data_consented[[3]] <- rbind(data_consented[[1]], data_consented[[2]])

# Get the number of people who opened the survey, but did not answer anything
unique_data <- list()
tmp2 <- NULL
for (i in 1:2){
  coln <- as.numeric(unlist(strsplit(coln_df[,i], ", ")))
  for (j in 1:nrow(data_consented[[i]])){
    unique_data[[j]] <- unique(unlist(data_consented[[i]][j,coln]))
    pos <- which(unique_data[[j]] == "Unchecked" | unique_data[[j]] == "")
    if (length(pos) > 0){
      unique_data[[j]] <- unique_data[[j]][-pos]
    }
    if (length(as.character(na.omit(unique_data[[j]]))) == 0){
      tmp2 <- c(tmp2, j)
      # tmp3 <- c(tmp3, j)
    }
  }
}

#################################################################################################

# Put in dataframe
survey_data <- cbind(
  tool = tool,
  survey_name = longname,
  date = date,
  provider = NA,
  ref_number = NA,
  age = age,
  sex = NA,
  self_reported_gender = sr_gender,
  emr_recorded_language = NA,
  n_medical_conditions = NA,
  postal_codes = postal_codes,
  rural_or_urban = rural_urban,
  language_most_spoken_home_cleaned = most_spoken_home,
  language_most_spoken_home = most_spoken_home,
  allophones_preferred_language_Canada = official_lang,
  preferred_language_written = preferred_lang_written,
  level_EN_or_FR = level_EN_FR,
  education_level_cleaned = education_level,
  education_level = education_level,
  racial_group_cleaned = racial_group,
  racial_group = racial_group,
  messages_understand = messages_understand,
  messages_value = messages_value,
  share_info = share_info,
  npeople_shared = npeople_shared,
  resources_sugg_cleaned = resources_sugg,
  resources_sugg = resources_sugg,
  source_fd = source_fd,
  source_pharmacist = source_pharmacist,
  source_family = source_family,
  source_gvt = source_gvt,
  source_localph = source_localph,
  source_radio = source_radio,
  source_tv = source_tv,
  source_newspapers = source_newspapers,
  source_social = source_social,
  source_other = source_other
)

response_rate <- cbind(
  tool = tool,
  survey_name = longname,
  # provider = Providers[i],
  provider = NA,
  n_sent = NA,
  n_undelivered = NA,
  # n_responded = nrow(data),
  n_responded = nrow(data[[3]]),
  n_consented = nrow(data_consented[[3]]),
  n_opened_but_no_answer = length(tmp2)
)
survey_data <- as.data.frame(survey_data)
response_rate <- as.data.frame(response_rate)

# Export as CSV
write.table(survey_data, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_data.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")
write.table(response_rate, paste0(output_dir, "/", today, "_", shortname, "_", tool, "_responserate.txt"), sep = "\t", row.names = F, quote = F, na = "#N/A")

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
