
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on September 1, 2026

#################################################################################################

                                      #####################
                                      # Declare functions #
                                      #####################

# Function 1
categorize_age <- function(all_ages){
  # num -> str
  #
  # Input:
  #   - all_ages: num vector containing ages of all participants
  #
  # Put the ages in categories
  
  tmp <- NULL
  
  for (i in all_ages){
    if (is.na(i)){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else if (i == "Missing/did not answer"){
      tmp <- c(tmp, i)
    }else{
      if (i >= 18 & i <= 34){
        tmp <- c(tmp, "18-34")
      }else if (i >= 35 & i <= 49){
        tmp <- c(tmp, "35-49")
      }else if (i >= 50 & i <= 69){
        tmp <-  c(tmp, "50-69")
      }else if (i >= 70){
        tmp <- c(tmp, "70+")
      }
    }
  }
  return(tmp)
}

# Function 2
categorize_med_cond <- function(all_med_conds){
  # num -> str
  #
  # Input:
  #   - all_med_conds: num vector containing medical conditions of all participants
  #
  # Puts the med_conds in categories
  
  tmp <- NULL
  
  for (i in all_med_conds){
    if (is.na(i)){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else{
      if (i == 0 | i == 1){
        tmp <- c(tmp, "0-1")
      }else if (i == 2 | i == 3){
        tmp <- c(tmp, "2-3")
      }else if (i == 4 | i == 5){
        tmp <-  c(tmp, "4-5")
      }else if (i >= 6 & i <= 9){
        tmp <- c(tmp, "6-9")
      }else if (i >= 10){
        tmp <- c(tmp, "10+")
      }
    }
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(readxl)
library(gtsummary)
library(dplyr)
library(stringr)

# To modify
today <- "260901"
tool <- c("Cliniconex", "Qualtrics", "REDCap")
# tool <- c("Qualtrics", "REDCap") # Already done Cliniconex
filename <- "/Users/username/Documents/Manuscripts/Final datasets used/260811_CPIN_MS1_DataCleaned_reordered.xlsx"
tab_name <- c("Survey 1 - Umbrella (cleaned)", "CPIN OLMC (cleaned)", "Survey 1 - ACHH (cleaned)", "Survey 2 - ACHH (cleaned)", "Survey 2 - ACHH (consent) (cle)", "Survey 2 - ACHH 2.0 (cleaned)", "Vaccine Hesitancy (cleaned)", "Vaccine Hesitancy - All c (cle)")
db_filename <- "/Users/username/Documents/Projets/CPIN Data Analysis/tbl1a-en.csv"
output_dir <- "/Users/username/Documents/Projets/CPIN Data Analysis/Analyzed data/"
# var <- c("age", "sex", "postal_codes", "rural_or_urban", "n_medical_conditions", "self_reported_gender", "education_level_cleaned", "racial_group_cleaned", "lgbt", "emr_recorded_language", "language_most_spoken_home_cleaned", "mother_tongue_cleaned")
# var <- c("age", "sex", "postal_codes", "rural_or_urban", "n_medical_conditions", "emr_recorded_language", "days_to_respond")
var <- c("age_cleaned", "sex_cleaned", "postal_codes_cleaned", "rural_or_urban_cleaned", "n_medical_conditions_cleaned", "emr_recorded_language_cleaned", "days_to_respond")

#################################################################################################
#################################################################################################

# Read all tabs
data <- list()
for (i in 1:length(tab_name)){
  data[[tab_name[i]]] <- as.data.frame(read_xlsx(filename, sheet = tab_name[i]))
  
  # Create a new column for LGBTQ+
  data[[tab_name[i]]]$lgbtq <- NA
  pos <- grep("LGTBQ2\\+", data[[tab_name[i]]]$racial_group_cleaned)
  if (length(pos) > 0){
    data[[tab_name[i]]]$lgbtq[pos] <- "LGBTQ2+"
    data[[tab_name[i]]]$racial_group_cleaned <- gsub(", LGTBQ2\\+", "", data[[tab_name[i]]]$racial_group_cleaned)
    data[[tab_name[i]]]$racial_group_cleaned <- gsub("LGTBQ2\\+, ", "", data[[tab_name[i]]]$racial_group_cleaned)
    data[[tab_name[i]]]$racial_group_cleaned <- gsub("^LGTBQ2\\+$, ", "Missing/did not answer", data[[tab_name[i]]]$racial_group_cleaned)
  }
}

# Get all providers
all_providers <- NULL
for (i in 1:length(tab_name)){
  data[[i]]$provider <- gsub("^Melissa Guindon$", "Melissa Guindon-BHAK", data[[i]]$provider)
  all_providers <- c(all_providers, unique(data[[i]]$provider))
}
all_providers <- sort(unique(all_providers))

# Check for duplicates
duplicated_df <- NULL
for (i in 1:length(all_providers)){
  tmp <- list()
  tmp2 <- NULL
  
  for (j in 1:length(tab_name)){
    tmp[[tab_name[j]]] <- as.character(na.omit(data[[j]]$ref_number_cleaned[which(data[[j]]$provider == all_providers[i])]))
    if (length(tmp[[tab_name[j]]]) > 0){
      tool_name <- data[[j]]$tool[which(data[[j]]$provider == all_providers[i])][1]
    }
    tmp2 <- c(tmp2, tmp[[tab_name[j]]])
  }
  tmp2 <- unique(tmp2)
  
  for (k in 1:length(tmp2)){
    tmp3 <- names(tmp)[unlist(lapply(tmp, function(x){tmp2[k] %in% x}))]
    if (length(tmp3) > 1){
      duplicated_df <- rbind(duplicated_df, cbind(Tool = tool_name,
                                                  Provider = all_providers[i],
                                                  ReferenceID = tmp2[k],
                                                  Duplicated = paste0(tmp3, collapse = "; ")))
    }
  }
}
duplicated_df <- as.data.frame(duplicated_df)
rm(i, j, k, tmp, tmp2, tmp3) # Clean space

# Check if information is the same for all var
all_duplicates <- duplicated_df$ReferenceID
TorF <- rep(FALSE, length(all_duplicates))
reason <- NULL
duplicated_data <- list()
# var2 <- var[-7] # Remove "days_to_respond"

for (i in 1:nrow(duplicated_df)){
  tmp <- strsplit(duplicated_df$Duplicated[i], "; ")[[1]]
  tmp2 <- list()
  tmp_reason <- NULL
  
  for (j in 1:length(tmp)){ # Get the data for all var
    tmp3 <- data[[tmp[j]]][which(data[[tmp[j]]]$ref_number_cleaned == all_duplicates[i]),]
    tmp2[[tmp[j]]] <- cbind(var = intersect(var, colnames(tmp3)), Values = as.character(unlist(tmp3[which(!is.na(tmp3$tool)),intersect(var, colnames(tmp3))]))) # var present
    if (nrow(tmp2[[tmp[j]]]) != length(var)){
      tmp2[[tmp[j]]] <- rbind(tmp2[[tmp[j]]], cbind(var = setdiff(var, colnames(tmp3)), Values = NA))
    }
    tmp2[[tmp[j]]] <- tmp2[[tmp[j]]][match(var, tmp2[[tmp[j]]][,1]),]
    tmp2[[tmp[j]]] <- as.character(tmp2[[tmp[j]]][,2])
    if (length(which(is.na(tmp2[[tmp[j]]]))) > 0){
      tmp2[[tmp[j]]][which(is.na(tmp2[[tmp[j]]]))] <- "NA"
    }
  }
  duplicated_data[[i]] <- tmp2
  
  # Are they identical?
  if (length(tmp2) == 2){
    if (identical(tmp2[[1]], tmp2[[2]])){
      TorF[i] <- TRUE
      reason <- c(reason, NA)
    }else{
      pos <- which(tmp2[[1]] != tmp2[[2]])
      if (length(pos) > 0){
        for (j in pos){
          # Is this because of a NA?
          if ("NA" %in% c(tmp2[[1]][j], tmp2[[2]][j])){
            tmp_reason <- c(tmp_reason, paste0(var[j], "_NA"))
          }else if (j == 1 | j == 4){
            tmp_reason <- c(tmp_reason, paste0(var[j], "_", abs(as.numeric(tmp2[[1]][j]) - as.numeric(tmp2[[2]][j]))))
          }else if (j == 2){
            if ("Others" %in% c(tmp2[[1]][j], tmp2[[2]][j])){
              tmp_reason <- c(tmp_reason, paste0(var[j], "_Others"))
            }
          }else{
            tmp_reason <- c(tmp_reason, var[j])
          }
        }
      }
      reason <- c(reason, paste0(tmp_reason, collapse = "; "))
    }
    
  }else if (length(tmp2) == 3){
    if (identical(tmp2[[1]], tmp2[[2]]) & identical(tmp2[[2]], tmp2[[3]])){
      TorF[i] <- TRUE
      reason <- c(reason, NA)
    }else{
      pos <- which(tmp2[[1]] != tmp2[[2]])
      pos <- unique(c(pos, which(tmp2[[1]] != tmp2[[3]])))
      if (length(pos) > 0){
        for (j in pos){
          # Is this because of a NA?
          if ("NA" %in% c(tmp2[[1]][j], tmp2[[2]][j], tmp2[[3]][j])){
            tmp_reason <- c(tmp_reason, paste0(var[j], "_NA"))
          }else if (j == 1 | j == 4){
            tmp_reason <- c(tmp_reason, paste0(var[j], "_", abs(as.numeric(tmp2[[1]][j]) - as.numeric(tmp2[[2]][j]))))
            # stop("TEST")
          }else{
            tmp_reason <- c(tmp_reason, var[j])
          }
        }
      }
      reason <- c(reason, paste0(tmp_reason, collapse = "; "))
    }
  }
}
duplicated_df$identical <- TorF
duplicated_df$reason <- reason
names(duplicated_data) <- duplicated_df$ReferenceID
rm(tmp2, tmp3, i, j, pos, reason, tmp, tmp_reason, TorF) # Clean space

#################################################################################################

# Go through the list: which data should I keep?
data_to_keep <- NULL
for (i in 1:length(duplicated_data)){
  tmp1 <- duplicated_data[[i]][[1]]
  tmp2 <- duplicated_data[[i]][[2]]
  
  if (length(duplicated_data[[i]]) == 2){
    # For each position, what are the values that are not NA?
    tmp1 <- gsub("NA", NA, tmp1)
    tmp2 <- gsub("NA", NA, tmp2)
    
    tmp_to_keep <- NULL
    for (j in 1:length(var)){
      tmp <- as.character(na.omit(c(tmp1[j], tmp2[j])))
      
      if (j == 7){ # days to respond
        # Find the dates the survey was completed
        dates_completed <- NULL
        names_survey <- names(duplicated_data[[i]])
        for (k in names_survey){
          dates_completed <- c(dates_completed, as.character(na.omit(data[[k]]$date[data[[k]]$ref_number_cleaned == names(duplicated_data)[i]])))
        }
        pos <- which(dates_completed == min(dates_completed))
        tmp_to_keep <- c(tmp_to_keep, tmp[pos[1]])
        
      }else{
        if (length(tmp) == 1){
          tmp_to_keep <- c(tmp_to_keep, tmp)
        }else if (length(tmp) > 1){
          if (length(unique(tmp)) == 1){
            tmp_to_keep <- c(tmp_to_keep, tmp[1])
          }else{
            if (j == 2){
              pos <- which(tmp != "Others")
              if (length(pos) > 0){
                tmp_to_keep <- c(tmp_to_keep, tmp[pos])
              }
            }else{
              pos <- which(tmp != "Missing/did not answer")
              if (length(pos) == 1){
                tmp_to_keep <- c(tmp_to_keep, tmp[pos])
              }else{
                # Find the dates the survey was completed
                dates_completed <- NULL
                names_survey <- names(duplicated_data[[i]])
                for (k in names_survey){
                  dates_completed <- c(dates_completed, as.character(na.omit(data[[k]]$date[data[[k]]$ref_number_cleaned == names(duplicated_data)[i]])))
                }
                pos <- which(dates_completed == min(dates_completed))
                tmp_to_keep <- c(tmp_to_keep, tmp[pos[1]])
              }
            }
          }
        }else if (length(tmp) == 0){
          tmp_to_keep <- c(tmp_to_keep, NA)
        }
      }
      
      
      
      
      
    }
    data_to_keep <- rbind(data_to_keep, c(all_duplicates[i], tmp_to_keep))
    
  }else if (length(duplicated_data[[i]]) == 3){
    tmp3 <- duplicated_data[[i]][[3]]
    
    # For each position, what are the values that are not NA?
    tmp1 <- gsub("NA", NA, tmp1)
    tmp2 <- gsub("NA", NA, tmp2)
    tmp3 <- gsub("NA", NA, tmp3)
    
    tmp_to_keep <- NULL
    for (j in 1:length(var)){
      tmp <- as.character(na.omit(c(tmp1[j], tmp2[j], tmp3[j])))
      
      if (j == 7){ # days to respond
        # Find the dates the survey was completed
        dates_completed <- NULL
        names_survey <- names(duplicated_data[[i]])
        for (k in names_survey){
          dates_completed <- c(dates_completed, as.character(na.omit(data[[k]]$date[data[[k]]$ref_number_cleaned == names(duplicated_data)[i]])))
        }
        pos <- which(dates_completed == min(dates_completed))
        tmp_to_keep <- c(tmp_to_keep, tmp[pos[1]])
        
      }else{
        if (length(tmp) == 1){
          tmp_to_keep <- c(tmp_to_keep, tmp)
        }else if (length(tmp) > 1){
          if (length(unique(tmp)) == 1){
            tmp_to_keep <- c(tmp_to_keep, tmp[1])
          }else{
            if (j == 2){
              pos <- which(tmp != "Others")
              if (length(pos) > 0){
                tmp_to_keep <- c(tmp_to_keep, tmp[pos])
              }
            }else{
              pos <- which(tmp != "Missing/did not answer")
              if (length(pos) == 1){
                tmp_to_keep <- c(tmp_to_keep, tmp[pos])
              }else{ # Take the first answer
                # Find the dates the survey was completed
                dates_completed <- NULL
                names_survey <- names(duplicated_data[[i]])
                for (k in names_survey){
                  dates_completed <- c(dates_completed, as.character(na.omit(data[[k]]$date[data[[k]]$ref_number_cleaned == names(duplicated_data)[i]])))
                }
                pos <- which(dates_completed == min(dates_completed))
                tmp_to_keep <- c(tmp_to_keep, tmp[pos])
              }
            }
          }
        }else if (length(tmp) == 0){
          tmp_to_keep <- c(tmp_to_keep, NA)
        }
      }
    }
    data_to_keep <- rbind(data_to_keep, c(all_duplicates[i], tmp_to_keep))
  }
}
data_to_keep <- as.data.frame(data_to_keep)
data_to_keep <- cbind(data_to_keep[,1], data_to_keep[,1], data_to_keep)
colnames(data_to_keep) <- c("Tool", "Provider", "ReferenceID", var)
rm(dates_completed, i, j, k, names_survey, pos, tmp, tmp_to_keep, tmp1, tmp2, tmp3) # Clean space

# Add provider and tool
for (i in 1:nrow(data_to_keep)){
  data_to_keep$Provider[i] <- duplicated_df$Provider[duplicated_df$ReferenceID == data_to_keep$ReferenceID[i]]
  data_to_keep$Tool[i] <- duplicated_df$Tool[duplicated_df$ReferenceID == data_to_keep$ReferenceID[i]]
}

# Get the data of unduplicated patients
for (i in 1:length(tab_name)){
  tmp_to_keep <- NULL
  tmp <- data[[tab_name[i]]]
  providers <- as.character(unique(na.omit(tmp$provider)))
  
  for (k in 1:length(providers)){
    pos <- match(intersect(as.character(na.omit(tmp$ref_number_cleaned[tmp$provider == providers[k]])), duplicated_df$ReferenceID[duplicated_df$Provider == providers[k]]), tmp$ref_number_cleaned)
    if (length(pos) > 0){
      tmp <- tmp[-pos,] # Remove 'duplicates'
    }
  }
  
  if (nrow(tmp) > 0){
    for (j in var){
      if (j %in% colnames(tmp)){
        tmp_to_keep <- cbind(tmp_to_keep, tmp[,j])
      }else{
        tmp_to_keep <- cbind(tmp_to_keep, NA)
      }
    }
    tmp_to_keep <- cbind(Tool = tmp$tool, Provider = tmp$provider, ReferenceID = tmp$ref_number_cleaned, tmp_to_keep)
    colnames(tmp_to_keep) <- c("Tool", "Provider", "ReferenceID", var)
    data_to_keep <- rbind(data_to_keep, tmp_to_keep)
  }
}
rm(tmp, tmp_to_keep, i, j, pos) # Clean space
data_to_keep <- as.data.frame(data_to_keep)

#################################################################################################

# Clean data
# Reformat postal code
data_to_keep$postal_codes_cleaned <- str_to_upper(data_to_keep$postal_codes_cleaned)
to_modify <- c(grep("^K1F", data_to_keep$postal_codes_cleaned),
               grep("^K2N", data_to_keep$postal_codes_cleaned),
               grep("^K4V", data_to_keep$postal_codes_cleaned),
               grep("^V2D", data_to_keep$postal_codes_cleaned),
               grep("^K1$", data_to_keep$postal_codes_cleaned),
               grep("^K2$", data_to_keep$postal_codes_cleaned),
               grep("^K3A", data_to_keep$postal_codes_cleaned),
               grep("^K44", data_to_keep$postal_codes_cleaned),
               grep("^K7Z", data_to_keep$postal_codes_cleaned),
               grep("^J9$", data_to_keep$postal_codes_cleaned),
               grep("^K2F", data_to_keep$postal_codes_cleaned),
               grep("^K0T", data_to_keep$postal_codes_cleaned),
               grep("^K6G", data_to_keep$postal_codes_cleaned),
               grep("^K02", data_to_keep$postal_codes_cleaned),
               grep("^K4T", data_to_keep$postal_codes_cleaned),
               grep("^A6J", data_to_keep$postal_codes_cleaned),
               grep("^K0P", data_to_keep$postal_codes_cleaned),
               grep("^K2N", data_to_keep$postal_codes_cleaned),
               grep("^K4N", data_to_keep$postal_codes_cleaned)
)
data_to_keep$rural_or_urban_cleaned[to_modify] <- "Cannot be extracted from the EMR"
data_to_keep$rural_or_urban_cleaned[which(is.na(data_to_keep$rural_or_urban_cleaned))] <- "Cannot be extracted from the EMR"
data_to_keep$postal_codes_cleaned[to_modify] <- "Cannot be extracted from the EMR"
data_to_keep$postal_codes_cleaned <- gsub("CANNOT BE EXTRACTED FROM THE EMR", "Cannot be extracted from the EMR", data_to_keep$postal_codes_cleaned)

#################################################################################################

# Age
data_to_keep$agecat <- categorize_age(data_to_keep$age)

# Medical conditions
data_to_keep$medcontcat <- categorize_med_cond(as.numeric(data_to_keep$n_medical_conditions))

# Add mean neighborhood income
db_income <- read.csv(db_filename) # Load DB
data_to_keep$totalincome <- data_to_keep$postal_codes_cleaned
all_pc <- unique(as.character(na.omit(data_to_keep$totalincome)))
for (i in 1:length(all_pc)){
  pos <- which(db_income$FSA == all_pc[i])
  pos2 <- which(data_to_keep$totalincome == all_pc[i])
  if (length(pos) > 0){
    data_to_keep$totalincome[pos2] <- (db_income$Total.income[pos]*1000)/db_income$Total[pos]
  }else{
    data_to_keep$totalincome[pos2] <- "Cannot be extracted from database"
  }
}
data_to_keep$totalincome <- as.numeric(data_to_keep$totalincome)

# Get total income category
data_to_keep$totalincomecat <- data_to_keep$totalincome
data_to_keep$totalincomecat[which(data_to_keep$totalincome < 25000)] <- "$0 to $24,999"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 25000 & data_to_keep$totalincome < 50000)] <- "$25,000 to $50,000"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 50000 & data_to_keep$totalincome < 75000)] <- "$50,000 to $75,000"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 75000 & data_to_keep$totalincome < 100000)] <- "$75,000 to $100,000"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 100000 & data_to_keep$totalincome < 125000)] <- "$100,000 to $125,000"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 125000 & data_to_keep$totalincome < 150000)] <- "$125,000 to $150,000"
data_to_keep$totalincomecat[which(data_to_keep$totalincome >= 150000)] <- "$150,000+"
data_to_keep$totalincomecat[which(is.na(data_to_keep$totalincomecat))] <- "Cannot be extracted from the EMR"

# Transform dates
data_to_keep$days_to_respond <- as.numeric(data_to_keep$days_to_respond)
data_to_keep$days_to_respond2 <- data_to_keep$days_to_respond
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond == 1)] <- "1 day"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond == 2)] <- "2 days"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond == 3)] <- "3 days"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond >= 4 & data_to_keep$days_to_respond <= 7)] <- "Between 4 and 7 days"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond >= 8 & data_to_keep$days_to_respond <= 14)] <- "Between 8 and 14 days"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond >= 15 & data_to_keep$days_to_respond <= 30)] <- "Between 15 and 30 days"
data_to_keep$days_to_respond2[which(data_to_keep$days_to_respond > 30)] <- "More than 30 days"
data_to_keep$days_to_respond2[is.na(data_to_keep$days_to_respond)] <- "Could not be determined"

#################################################################################################

# Change "Cannot be extracted from the EMR" to NA
data_to_keep <- as.data.frame(lapply(data_to_keep, function(x){gsub("Cannot be extracted from the EMR", NA, x)}))

#################################################################################################


# Table by delivery mode
data_to_keep |>
  filter(Tool == "Cliniconex") |>
  select('agecat', 'sex_cleaned', 'rural_or_urban_cleaned', 'totalincomecat', 'medcontcat', 'emr_recorded_language_cleaned', 'days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_to_keep |>
  filter(Tool == "Qualtrics") |>
  select('agecat', 'sex_cleaned', 'rural_or_urban_cleaned', 'totalincomecat', 'medcontcat', 'emr_recorded_language_cleaned', 'days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_to_keep |>
  filter(Tool == "REDCap") |>
  select('agecat', 'rural_or_urban_cleaned', 'totalincomecat', 'days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
