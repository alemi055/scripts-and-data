
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on August 26, 2026

#################################################################################################

# Function 1
get_rural_urban <- function(three_digits_postalcode){
  # str -> str
  #
  # Input:
  #   - three_digits_postalcode: str vector containing the three first characters of the postal codes of all patients
  #
  # In Canada, the number of the Forward Sortation Area (FSA) indicates whether is it rural (0) or urban (1-9)
  # Returns if the postal code is rural or urban

  tmp <- NULL

  for (i in three_digits_postalcode){
    if (is.na(i)){
      tmp <- c(tmp, NA)
    }else{
      tmp2 <- as.numeric(strsplit(i, "")[[1]][2])
      if (tmp2 == 0){
        tmp <- c(tmp, "rural")
      }else{
        tmp <- c(tmp, "urban")
      }
    }
  }
  return(tmp)
}

# Function 2
categorize_age <- function(all_ages){
  # num -> str
  #
  # Input:
  #   - all_ages: num vector containing ages of all participants
  #
  # Put the ages in categories

  tmp <- NULL

  for (i in all_ages){
    if (is.na(i)){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else{
      if (i >= 18 & i <= 34){
        tmp <- c(tmp, "18-34")
      }else if (i >= 35 & i <= 49){
        tmp <- c(tmp, "35-49")
      }else if (i >= 50 & i <= 69){
        tmp <-  c(tmp, "50-69")
      }else if (i >= 70){
        tmp <- c(tmp, "70+")
      }
    }
  }
  return(tmp)
}

#################################################################################################

# Load libraries
library(readxl)
library(stringr)
library(lubridate)
library(dplyr)
library(gtsummary)
library(openxlsx)

# To modify
today <- "260826"
patients_filename <- "/Users/username/Documents/Projets/CPIN Data Analysis/260811_ListPatients_noID_notestdata.xlsx"
resp_filename <- "/Users/username/Documents/Manuscripts/Final datasets used/260811_CPIN_MS1_DataCleaned_reordered.xlsx"
tab_name <- c("Survey 1 - Umbrella (cleaned)", "CPIN OLMC (cleaned)", "Survey 1 - ACHH (cleaned)", "Survey 2 - ACHH (cleaned)", "Survey 2 - ACHH (consent) (cle)", "Survey 2 - ACHH 2.0 (cleaned)", "Vaccine Hesitancy (cleaned)", "Vaccine Hesitancy - All c (cle)")
db_filename <- "/Users/username/Documents/Projets/CPIN Data Analysis/tbl1a-en.csv"
output_dir <- "/Users/username/Documents/Projets/CPIN Data Analysis/Analyzed data/Data analyzed/By tool"
# var <- c("PatientDoctor_MDName", "Birthdate", "Surname", "First Name", "Sex", "Language Code", "Postal Code", "Current # Rx/Meds/Treatments", "Health Number")
var <- c("PatientDoctor_MDName", "Patient #", "Birthdate", "Sex", "Language Code", "Postal Code", "Current # Rx/Meds/Treatments")

#################################################################################################
#################################################################################################

# Read each tab and put in a data frame
dates_sent <- read_xlsx(patients_filename, sheet = "DatesSent")
data <- NULL

for (i in 1:length(tab_name)){
  cat(paste0("\n--- Now at Survey: ", tab_name[i], " ---\n"))
  pos <- which(dates_sent$Project == tab_name[i])

  for (j in 1:length(pos)){
    cat(paste0("--- Now at Tab: ", dates_sent$Tab_name[pos[j]], " ---\n"))
    tmp <- read_xlsx(patients_filename, sheet = dates_sent$Tab_name[pos[j]])

    if (nrow(tmp) > 0){
      if (length(grep("Patient Chart#", colnames(tmp))) > 0){
        tmp <- tmp[,-grep("Patient Chart#", colnames(tmp))]
      }
      data <- rbind(data, cbind(survey = tab_name[i], tab = dates_sent$Tab_name[pos[j]], tmp[,var]))
    }
  }
}
rm(tmp, i, j, pos) # Clean space

# Remove our test data
pos <- which(data$PatientDoctor_MDName == "Sharon Johnston")
if (length(pos) > 0){
  data <- data[-pos,]
}
# save.image(paste0(today, "_ListPatients.RData"))

#################################################################################################

# Get the number of patients per survey, per provider
npatients_df <- NULL
for (i in 1:length(tab_name)){
  tmp <- data[data$survey == tab_name[i],]
  npatients_df <- rbind(npatients_df, cbind(survey = tab_name[i], as.data.frame(table(tmp$PatientDoctor_MDName))))
}

#################################################################################################

# Convert dates format
# dd-mm-YY
pos1 <- grep("-", data$Birthdate)
for (i in pos1){
  tmp <- as.numeric(substr(data$Birthdate[i], 8, 9))
  if (tmp > 5){
    tmp <- paste0(substr(data$Birthdate[i], 1, 7), "19", substr(data$Birthdate[i], 8, 9))
  }else{
    tmp <- paste0(substr(data$Birthdate[i], 1, 7), "20", substr(data$Birthdate[i], 8, 9))
  }
  data$Birthdate[i] <- as.character(as.Date(parse_date_time(tmp, order = c("d-b-Y"))))
}

# dd/mm/YYYY
pos2 <- grep("\\/", data$Birthdate)
data$Birthdate[pos2] <- as.character(as.Date(data$Birthdate[pos2], format = "%d/%m/%Y"))

# Mmm dd, YYYY
pos3 <- grep(",", data$Birthdate)
data$Birthdate[pos3] <- as.character(as.Date(parse_date_time(data$Birthdate[pos3], order = c("b d, Y"))))

# Else
pos <- setdiff(1:nrow(data), c(pos1, pos2, pos3))
data$Birthdate[pos] <- as.character(convertToDate(data$Birthdate[pos]))
rm(pos, pos1, pos2, i) # Clean space

# Reformat postal code
data$`Postal Code` <- str_to_upper(data$`Postal Code`)
data$`Postal Code`[which(data$`Postal Code` == "3124")] <- NA
data$`Postal Code`[which(data$`Postal Code` == "J")] <- NA
data$`Postal Code`[which(data$`Postal Code` == "PR97DR")] <- NA
data$`Postal Code`[which(data$`Postal Code` == "OTT")] <- NA
data$`Postal Code`[which(data$`Postal Code` == "K1D 5H3")] <- NA # Doesn't exist
data$`Postal Code`[which(data$`Postal Code` == "K2")] <- NA # Doesn't exist
data$`Postal Code`[grep("^K1F", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K5A", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4T", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K0W", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K1O", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K1I", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K7J", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K9T", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K2N", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^J8W", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^G3T", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K3C", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K0V", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^H0H", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^P30", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4H", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4E", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4V", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4W", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^J0F", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^Z0E", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^V2D", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[which(data$`Postal Code` == "K1")] <- NA # Doesn't exist
data$`Postal Code`[grep("^T1T", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K18", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[which(data$`Postal Code` == "K4")] <- NA # Doesn't exist
data$`Postal Code`[grep("^G9G", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^M0V", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^L6N", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code`[grep("^K4N", data$`Postal Code`)] <- NA # Doesn't exist
data$`Postal Code` <- str_replace_all(data$`Postal Code`, "([A-Z]\\d[A-Z]) ?(\\d[A-Z]\\d)?", "\\1 \\2")
data$`Postal Code` <- str_trim(data$`Postal Code`)

# Correct some typos
data$Birthdate <- gsub("2027", "1927", data$Birthdate)
data$Birthdate <- gsub("2028", "1928", data$Birthdate)
data$Birthdate <- gsub("2029", "1929", data$Birthdate)

# Calculate age
# dates_sent$Date_sent <- as.character(as.Date(parse_date_time(dates_sent$Date_sent_survey, order = c("b d, Y"))))
dates_sent$Date_sent_survey <- as.character(as.Date(dates_sent$Date_sent_survey))
data$age <- data$Birthdate

for (i in 1:length(tab_name)){
  tmp <- dates_sent[which(dates_sent$Project == tab_name[i]),]
  for (j in 1:nrow(tmp)){
    pos <- which(data$tab == tmp$Tab_name[j])
    data$age[pos] <- floor(time_length(difftime(tmp$Date_sent_survey[j], data$Birthdate[pos]), unit = "years"))
  }
}

################################################################################################

# Clean it up
data$Sex[which(is.na(data$Sex))] <- "Cannot be extracted from the EMR"

#################################################################################################

# Remove duplicates
providers <- sort(unique(na.omit(data$PatientDoctor_MDName)))
data_no_dups <- NULL

for (i in 1:length(providers)){
  to_erase <- NULL
  tmp <- data[which(data$PatientDoctor_MDName == providers[i]),3:ncol(data)]
  tmp <- distinct(tmp)
  duplicated_pts <- names(which(table(tmp$`Patient #`) >= 2))
  if (length(duplicated_pts) > 0){ # If data is not the same between the two lists, take the first
    for (j in 1:length(duplicated_pts)){
      pos <- which(tmp$`Patient #` == duplicated_pts[j])
      to_erase <- c(to_erase, setdiff(pos, pos[1]))
    }
  }
  if (length(to_erase) > 0){
    tmp <- tmp[-unique(to_erase),]
  }
  data_no_dups <- rbind(data_no_dups, tmp)
}
rm(i, tmp) # Clean space

#################################################################################################

# Analyze data
pc <- data_no_dups$`Postal Code`
pc <- sapply(strsplit(pc, " "), "[", 1)
pc <- substr(pc, 1, 3)
pc[which(pc == "KIK")] <- "K1K" 
pc[which(pc == "KA6")] <- "K6A" 
pc[which(pc == "KOB")] <- "K0B"
pc[which(pc == "KIG")] <- "K1G" 
pc[which(pc == "KIN")] <- "K1N"
pc[which(pc == "KIJ")] <- "K1J"
to_modify <- c(grep("^K1F", pc),
               grep("^K2N", pc),
               grep("^K4V", pc),
               grep("^V2D", pc),
               grep("^K1$", pc),
               grep("^K2$", pc),
               grep("^K3A", pc),
               grep("^K44", pc),
               grep("^K7Z", pc),
               grep("^J9$", pc),
               grep("^K2F", pc),
               grep("^K0T", pc),
               grep("^K6G", pc),
               grep("^K02", pc),
               grep("^K4T", pc),
               grep("^A6J", pc),
               grep("^K0P", pc),
               grep("^K2N", pc),
               grep("^H0C", pc),
               grep("^K6G", pc),
               grep("^G9D", pc),
               grep("^K4N", pc),
               grep("^K1D", pc),
               grep("^K2O", pc)
)
pc[to_modify] <- NA
pc[which(pc == "Cannot be extracted from the EMR")] <- NA
data_no_dups$PostalCode_3 <- pc
data_no_dups$rural_urban <- "Cannot be extracted from EMR"
pc <- na.omit(pc)
data_no_dups$rural_urban[setdiff(1:nrow(data_no_dups), which(is.na(data_no_dups$PostalCode_3)))] <- get_rural_urban(pc)
data_no_dups$`Current # Rx/Meds/Treatments`[which(is.na(data_no_dups$`Current # Rx/Meds/Treatments`))] <- "Cannot be extracted from the EMR"

# Add neighborhood income
db_income <- read.csv(db_filename) # Load DB
data_no_dups$totalincome <- data_no_dups$PostalCode_3
all_pc <- unique(as.character(na.omit(data_no_dups$totalincome)))
for (i in 1:length(all_pc)){
  pos <- which(db_income$FSA == all_pc[i])
  pos2 <- which(data_no_dups$totalincome == all_pc[i])
  if (length(pos) > 0){
    data_no_dups$totalincome[pos2] <- (db_income$Total.income[pos]*1000)/db_income$Total[pos]
  }else{
    data_no_dups$totalincome[pos2] <- "Cannot be extracted from database"
  }
}
data_no_dups$totalincome <- as.numeric(data_no_dups$totalincome)

# Get total income category
data_no_dups$totalincomecat <- data_no_dups$totalincome
data_no_dups$totalincomecat[which(data_no_dups$totalincome < 25000)] <- "$0 to $24,999"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 25000 & data_no_dups$totalincome < 50000)] <- "$25,000 to $50,000"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 50000 & data_no_dups$totalincome < 75000)] <- "$50,000 to $75,000"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 75000 & data_no_dups$totalincome < 100000)] <- "$75,000 to $100,000"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 100000 & data_no_dups$totalincome < 125000)] <- "$100,000 to $125,000"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 125000 & data_no_dups$totalincome < 150000)] <- "$125,000 to $150,000"
data_no_dups$totalincomecat[which(data_no_dups$totalincome >= 150000)] <- "$150,000+"
data_no_dups$totalincomecat[which(is.na(data_no_dups$totalincomecat))] <- "Cannot be extracted from the EMR"

# Categorize medication
data_no_dups$`Current # Rx/Meds/Treatments`[grep("Cannot", data_no_dups$`Current # Rx/Meds/Treatments`)] <- NA
data_no_dups$`Current # Rx/Meds/Treatments` <- as.numeric(data_no_dups$`Current # Rx/Meds/Treatments`)
data_no_dups$medcondcat <- data_no_dups$`Current # Rx/Meds/Treatments` 
data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` == 0)] <- "0"
data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` == 1)] <- "1"
data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` == 2)] <- "2"
# data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` >= 2 & data_no_dups$`Current # Rx/Meds/Treatments` <= 3)] <- "2-3"
# data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` >= 3 & data_no_dups$`Current # Rx/Meds/Treatments` <= 4)] <- "3-4"
# data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` == 5)] <- "5"
data_no_dups$medcondcat[which(data_no_dups$`Current # Rx/Meds/Treatments` >= 3)] <- "3+"
data_no_dups$medcondcat[which(is.na(data_no_dups$`Current # Rx/Meds/Treatments`))] <- "Cannot be extracted from the EMR"

# Reformat language
data_no_dups$`Language Code` <-  str_to_upper(data_no_dups$`Language Code`)
data_no_dups$`Language Code`[which(data_no_dups$`Language Code` == "ENGLISH")] <- "EN"
data_no_dups$`Language Code`[which(is.na(data_no_dups$`Language Code`))] <- "Cannot be extracted from the EMR"

# Reformat
data_no_dups$Sex <- gsub("F", "Female", data_no_dups$Sex)
data_no_dups$Sex <- gsub("^M$", "Male", data_no_dups$Sex)
data_no_dups$Sex <- gsub("^O$", "Other", data_no_dups$Sex)

# Categorize age
data_no_dups$agecat <- categorize_age(as.numeric(data_no_dups$age))

#################################################################################################

# Non-respondents
# Extract data
data_resp <- NULL
for (i in 1:length(tab_name)){
  raw <- as.data.frame(read_xlsx(resp_filename, sheet = tab_name[i]))
  # raw$provider <- gsub("^Melissa Guindon$", "Melissa Guindon-BHAK", raw$provider)
  
  pos_other <- which(raw$tool != "Cliniconex")
  if (length(pos_other) > 0){
    raw <- raw[-pos_other,]
  }
  
  # Provider
  pos <- which(colnames(raw) == "provider")
  provider <- raw[,pos]
  
  # Reference number
  pos <- which(colnames(raw) == "ref_number_cleaned")
  ref_number <- raw[,pos]
  
  data_resp <- rbind(data_resp, cbind(survey = tab_name[i], provider = provider, ref_number = ref_number))
}
data_resp <- as.data.frame(data_resp)
# data_resp <- distinct(data_resp)
# data_resp <- data_resp[-which(is.na(data_resp$provider)),]
data_resp <- data_resp[-setdiff(1:nrow(data_resp), grep("PR", data_resp$ref_number)),]
rm(i, j, all_pc, pc, pos, pos2, provider, ref_number, db_income, raw, pos_other) # Clean space

# Add it to the npatients_df
tmp <- NULL
for (i in 1:nrow(npatients_df)){
  pos <- which(data_resp$survey == npatients_df$survey[i] & data_resp$provider == npatients_df$Var1[i])
  tmp <- c(tmp, length(pos))
}
npatients_df$Freq2 <- tmp
npatients_df$Freq3 <- npatients_df$Freq - npatients_df$Freq2
colnames(npatients_df)[2:ncol(npatients_df)] <- c("provider", "npatients", "nresponded", "non-respondents")

non_resp_df <- NULL
for (i in 1:length(providers)){
  tmp <- data_no_dups[data_no_dups$PatientDoctor_MDName == providers[i],]
  resp <- unique(data_resp$ref_number[which(data_resp$provider == providers[i])])
  print(paste0(providers[i], ": ", length(unique(resp))))
  non_resp <- unique(setdiff(tmp$`Patient #`, resp))
  non_resp_df <- rbind(non_resp_df, tmp[match(non_resp, tmp$`Patient #`),])
}

#################################################################################################

# Change "Cannot be extracted from the EMR" to NA
data_no_dups <- as.data.frame(lapply(data_no_dups, function(x){gsub("Cannot be extracted from the EMR", NA, x)}))
data_no_dups <- as.data.frame(lapply(data_no_dups, function(x){gsub("Cannot be extracted from EMR", NA, x)}))
non_resp_df <- as.data.frame(lapply(non_resp_df, function(x){gsub("Cannot be extracted from the EMR", NA, x)}))
non_resp_df <- as.data.frame(lapply(non_resp_df, function(x){gsub("Cannot be extracted from EMR", NA, x)}))

#################################################################################################

# Summarize data
# All patients
data_no_dups |>
  select('agecat', 'Sex', 'rural_urban', 'totalincomecat', 'medcondcat', 'Language.Code') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

# Non-respondents
non_resp_df %>%
  select('agecat', 'Sex', 'rural_urban', 'totalincomecat', 'medcondcat', 'Language.Code') %>%
  tbl_summary(missing = "ifany", digits = list(all_categorical() ~ c(0, 1)))

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
