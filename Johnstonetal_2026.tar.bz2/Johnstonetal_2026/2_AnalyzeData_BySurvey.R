
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on September 1, 2026

#################################################################################################

                                      #####################
                                      # Declare functions #
                                      #####################

# Function 1
categorize_age <- function(all_ages){
  # num -> str
  #
  # Input:
  #   - all_ages: num vector containing ages of all participants
  #
  # Put the ages in categories
  
  tmp <- NULL
  
  for (i in all_ages){
    if (is.na(i)){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else if (i == "Missing/did not answer"){
      tmp <- c(tmp, i)
    }else{
      if (i >= 18 & i <= 34){
        tmp <- c(tmp, "18-34")
      }else if (i >= 35 & i <= 49){
        tmp <- c(tmp, "35-49")
      }else if (i >= 50 & i <= 69){
        tmp <-  c(tmp, "50-69")
      }else if (i >= 70){
        tmp <- c(tmp, "70+")
      }
    }
  }
  return(tmp)
}

# Function 2
extract_data_EMR <- function(x){
  tmp <- NULL
  
  for (i in 1:length(x)){
    if (is.na(x[i])){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else{
      tmp <- c(tmp, x[i])
    }
  }
  return(tmp)
}

# Function 3
categorize_med_cond <- function(all_med_conds){
  # num -> str
  #
  # Input:
  #   - all_med_conds: num vector containing medical conditions of all participants
  #
  # Puts the med_conds in categories
  
  tmp <- NULL
  
  for (i in all_med_conds){
    if (is.na(i)){
      tmp <- c(tmp, "Cannot be extracted from the EMR")
    }else{
      if (i == 0 | i == 1){
        tmp <- c(tmp, "0-1")
      }else if (i == 2 | i == 3){
        tmp <- c(tmp, "2-3")
      }else if (i == 4 | i == 5){
        tmp <-  c(tmp, "4-5")
      }else if (i >= 6 & i <= 9){
        tmp <- c(tmp, "6-9")
      }else if (i >= 10){
        tmp <- c(tmp, "10+")
      }
    }
  }
  return(tmp)
}

# Function 4
categorize_race <- function(variable){
  tmp2 <- NULL
  
  if ("LGTBQ2+" %in% variable){
    variable <- gsub(" LGBTQ2\\+, ", " ", variable)
    variable <- gsub(", LGBTQ2\\+$", "", variable)
    variable <- gsub("^LGBTQ2\\+, ", "", variable)
    variable <- gsub("LGTBQ2\\+", "Missing/did not answer", variable)
  }
  
  for (i in 1:length(variable)){
    tmp3 <- strsplit(variable[i], ",\\s+(?![^()]*\\))", perl = TRUE)[[1]]
    if (length(tmp3) == 1){
      tmp3 <- gsub(" \\(.*\\)", "", tmp3)
      tmp2 <- c(tmp2, tmp3)
    }else{
      tmp2 <- c(tmp2, "Multiracial")
    }
  }
  return(tmp2)
}

#################################################################################################

# Load libraries
library(readxl)
library(dplyr)
library(gtsummary)
library(stringr)

# To modify
today <- "260901"
clinics_filename <- "/Users/username/Documents/Manuscripts/Final datasets used/260811_CPIN_MS1_DataCleaned_reordered.xlsx"
tab_name <- c("Survey 1 - Umbrella (cleaned)", "CPIN OLMC (cleaned)", "Survey 1 - ACHH (cleaned)", "Survey 2 - ACHH (cleaned)", "Survey 2 - ACHH (consent) (cle)", "Survey 2 - ACHH 2.0 (cleaned)", "Vaccine Hesitancy (cleaned)", "Vaccine Hesitancy - All c (cle)")
db_filename <- "/Users/username/Documents/Projets/CPIN Data Analysis/tbl1a-en.csv"
output_dir <- "/Users/username/Documents/Projets/CPIN Data Analysis/Analyzed data/"

#################################################################################################
#################################################################################################

# Extract data
data_df <- common_df <- NULL

for (i in 1:length(tab_name)){
  raw <- as.data.frame(read_xlsx(clinics_filename, sheet = tab_name[i]))
  
  # Days to respond
  pos <- which(colnames(raw) == "days_to_respond")
  days_to_respond <- raw[,pos]
  
  # Ref number
  pos <- which(colnames(raw) == "ref_number_cleaned")
  ref_number <- raw[,pos]
  
  # Data extracted from the EMR
  # Age
  pos <- which(colnames(raw) == "age_cleaned")
  age <- categorize_age(raw[,pos])
  
  # Sex
  pos <- which(colnames(raw) == "sex_cleaned")
  sex <- extract_data_EMR(raw[,pos])
  
  # Region
  pos <- grep("rural", colnames(raw))
  region <- extract_data_EMR(raw[,pos])
  
  # Medical conditions
  pos <- grep("medical", colnames(raw))
  medical_cond <- categorize_med_cond(raw[,pos])
  
  # Postal code
  pos <- which(colnames(raw) == "postal_codes_cleaned")
  postalcode <- extract_data_EMR(raw[,pos])
  
  # In survey
  # Gender
  pos <- grep("gender", colnames(raw))
  if (length(pos) > 0){
    gender <- raw[,pos]
  }else{
    gender <- NA
  }
  
  # Education
  pos <- grep("education.*cleaned", colnames(raw))
  if (length(pos) > 0){
    education_level <- raw[,pos]
  }else{
    education_level <- NA
  }
  
  # Race group
  pos <- grep("racial.*cleaned", colnames(raw))
  if (length(pos) > 0){
    racial_group <- categorize_race(raw[,pos])
  }else{
    racial_group <- NA
  }
  
  # LGBTQ+
  if (length(pos) > 0 & ("LGTBQ2+" %in% raw[,pos])){
    lgbt <- rep("No", nrow(raw))
    lgbt[which(raw[,pos] == "Missing/did not answer")] <- "Missing/did not answer"
    lgbt[grep("LGTBQ2\\+", raw[,pos])] <-  "Yes"
  }else{
    lgbt <- NA
  }
  
  # Languages
  # EMR-recorded language
  pos <- grep("emr_recorded_language_cleaned", colnames(raw))
  emr_recorded_language <- extract_data_EMR(raw[,pos])
  
  # Language most spoken at home
  pos <- grep("most_spoken_home.*cleaned", colnames(raw))
  if (length(pos) > 0){
    language_most_spoken_home <- raw[,pos]
  }else{
    language_most_spoken_home <- NA
  }
  
  # Mother tongue
  pos <- grep("mother_tongue_cleaned", colnames(raw))
  if (length(pos) > 0){
    mother_tongue <- raw[,pos]
  }else{
    mother_tongue <- NA
  }
  
  # Allophones preferred official Canadian language
  pos <- grep("allophones_preferred", colnames(raw))
  if (length(pos) > 0){
    allophones_preferred_lang <- raw[,pos]
  }else{
    allophones_preferred_lang <- NA
  }
  
  # Allophones: level of EN/FR
  pos <- grep("level_EN", colnames(raw))
  if (length(pos) > 0){
    level_EN_FR <- raw[,pos]
  }else{
    level_EN_FR <- NA
  }
  
  # Preferred language written
  pos <- grep("written", colnames(raw))
  if (length(pos) > 0){
    preferred_written_lang <- raw[,pos]
  }else{
    preferred_written_lang <- NA
  }
  
  # (Everyone's) preferred official Canadian language
  pos <- grep("everyone", colnames(raw))
  if (length(pos) > 0){
    everyone_preferred_lang <- raw[,pos]
  }else{
    everyone_preferred_lang <- NA
  }
  
  # Combine in a df
  data_df <- rbind(data_df, cbind(
    survey = tab_name[i],
    days_to_respond = days_to_respond,
    ref_number = ref_number,
    age = age,
    sex = sex,
    region = region,
    medical_cond = medical_cond,
    postalcode = postalcode,
    gender = gender,
    education_level = education_level,
    racial_group = racial_group,
    lgbt = lgbt,
    emr_recorded_language = emr_recorded_language,
    language_most_spoken_home = language_most_spoken_home,
    mother_tongue = mother_tongue,
    allophones_preferred_lang = allophones_preferred_lang,
    level_EN_FR = level_EN_FR,
    preferred_written_lang = preferred_written_lang,
    everyone_preferred_lang = everyone_preferred_lang
  ))
}
data_df <- as.data.frame(data_df)
rm(raw, age, allophones_preferred_lang, education_level, emr_recorded_language, everyone_preferred_lang, gender,
   language_most_spoken_home, level_EN_FR, lgbt, medical_cond, mother_tongue, preferred_written_lang, racial_group,
   region, sex, i, pos, days_to_respond) # Clean space

# Reformat postal code
data_df$postalcode <- str_to_upper(data_df$postalcode)
to_modify <- c(grep("^K1F", data_df$postalcode),
               grep("^K2N", data_df$postalcode),
               grep("^K4V", data_df$postalcode),
               grep("^V2D", data_df$postalcode),
               grep("^K1$", data_df$postalcode),
               grep("^K2$", data_df$postalcode),
               grep("^K3A", data_df$postalcode),
               grep("^K44", data_df$postalcode),
               grep("^K7Z", data_df$postalcode),
               grep("^J9$", data_df$postalcode),
               grep("^K2F", data_df$postalcode),
               grep("^K0T", data_df$postalcode),
               grep("^K6G", data_df$postalcode),
               grep("^K02", data_df$postalcode),
               grep("^K4T", data_df$postalcode),
               grep("^A6J", data_df$postalcode),
               grep("^K0P", data_df$postalcode),
               grep("^K2N", data_df$postalcode),
               grep("^K4N", data_df$postalcode)
)
data_df$region[to_modify] <- "Cannot be extracted from the EMR" 
data_df$postalcode[to_modify] <- "Cannot be extracted from the EMR"
data_df$postalcode <- gsub("CANNOT BE EXTRACTED FROM THE EMR", "Cannot be extracted from the EMR", data_df$postalcode)

# Add mean neighborhood income
db_income <- read.csv(db_filename) # Load DB
data_df$totalincome <- data_df$postalcode
all_pc <- unique(as.character(na.omit(data_df$totalincome)))
for (i in 1:length(all_pc)){
  pos <- which(db_income$FSA == all_pc[i])
  pos2 <- which(data_df$totalincome == all_pc[i])
  if (length(pos) > 0){
    data_df$totalincome[pos2] <- (db_income$Total.income[pos]*1000)/db_income$Total[pos]
  }else{
    data_df$totalincome[pos2] <- "Cannot be extracted from database"
  }
}
data_df$totalincome <- as.numeric(data_df$totalincome)

# Get total income category
data_df$totalincomecat <- data_df$totalincome
data_df$totalincomecat[which(data_df$totalincome < 25000)] <- "$0 to $24,999"
data_df$totalincomecat[which(data_df$totalincome >= 25000 & data_df$totalincome < 50000)] <- "$25,000 to $50,000"
data_df$totalincomecat[which(data_df$totalincome >= 50000 & data_df$totalincome < 75000)] <- "$50,000 to $75,000"
data_df$totalincomecat[which(data_df$totalincome >= 75000 & data_df$totalincome < 100000)] <- "$75,000 to $100,000"
data_df$totalincomecat[which(data_df$totalincome >= 100000 & data_df$totalincome < 125000)] <- "$100,000 to $125,000"
data_df$totalincomecat[which(data_df$totalincome >= 125000 & data_df$totalincome < 150000)] <- "$125,000 to $150,000"
data_df$totalincomecat[which(data_df$totalincome >= 150000)] <- "$150,000+"
data_df$totalincomecat[which(is.na(data_df$totalincomecat))] <- "Cannot be extracted from the EMR"

# Change "Cannot be extracted" by NAs
data_df$age[which(data_df$age == "Cannot be extracted from the EMR"| data_df$age == "Missing/did not answer")] <- NA
data_df$sex[which(data_df$sex == "Cannot be extracted from the EMR")] <- NA
data_df$emr_recorded_language[which(data_df$emr_recorded_language == "Cannot be extracted from the EMR")] <- NA
data_df$medical_cond[which(data_df$medical_cond == "Cannot be extracted from the EMR")] <- NA
data_df$region[which(data_df$region == "Cannot be extracted from the EMR"| data_df$region == "Missing/did not answer")] <- NA
data_df$totalincomecat[which(data_df$totalincomecat == "Cannot be extracted from the EMR")] <- NA

# Transform dates
data_df$days_to_respond <- as.numeric(data_df$days_to_respond)
data_df$days_to_respond2 <- as.numeric(data_df$days_to_respond)
data_df$days_to_respond2[which(data_df$days_to_respond == 1)] <- "1 day"
data_df$days_to_respond2[which(data_df$days_to_respond == 2)] <- "2 days"
data_df$days_to_respond2[which(data_df$days_to_respond == 3)] <- "3 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 4 & data_df$days_to_respond <= 7)] <- "Between 4 and 7 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 8 & data_df$days_to_respond <= 14)] <- "Between 8 and 14 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 15 & data_df$days_to_respond <= 30)] <- "Between 15 and 30 days"
data_df$days_to_respond2[which(data_df$days_to_respond > 30)] <- "More than 30 days"
data_df$days_to_respond2[is.na(data_df$days_to_respond)] <- "Could not be determined"

# Get table (by survey)
data_df |>
  filter(survey == "Survey 1 - Umbrella (cleaned)") |>
  select('days_to_respond2', 'age', 'sex', 'gender', 'region', 'totalincomecat', 'medical_cond', 'education_level', 'racial_group', 'emr_recorded_language', 'language_most_spoken_home') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df |>
  filter(survey == "CPIN OLMC (cleaned)") |>
  select('days_to_respond2', 'age', 'sex', 'region', 'totalincomecat', 'medical_cond', 'emr_recorded_language', 'mother_tongue') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df |>
  filter(survey == "Survey 1 - ACHH (cleaned)") |>
  select('days_to_respond2', 'age', 'sex', 'region', 'totalincomecat', 'medical_cond', 'emr_recorded_language', 'mother_tongue', 'allophones_preferred_lang') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df |>
  filter(survey == "Survey 2 - ACHH (cleaned)" | survey == "Survey 2 - ACHH (consent) (cle)" | survey == "Survey 2 - ACHH 2.0 (cleaned)") |>
  select('days_to_respond2', 'age', 'sex', 'region', 'totalincomecat', 'medical_cond', 'emr_recorded_language', 'mother_tongue', 'allophones_preferred_lang') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df |>
  filter(survey == "Vaccine Hesitancy (cleaned)" | survey == "Vaccine Hesitancy - All c (cle)") |>
  select('days_to_respond2', 'age', 'sex', 'gender', 'region', 'totalincomecat', 'medical_cond', 'education_level', 'racial_group', 'emr_recorded_language', 'mother_tongue') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

#################################################################################################

# Survey 1 vs Survey 2
survey_1_ids <- data_df$ref_number[data_df$survey == "Survey 1 - ACHH (cleaned)"]
survey_2_ids <- c(data_df$ref_number[data_df$survey == "Survey 2 - ACHH (cleaned)"],
                  data_df$ref_number[data_df$survey == "Survey 2 - ACHH (consent) (cle)"],
                  data_df$ref_number[data_df$survey == "Survey 2 - ACHH 2.0 (cleaned)"])
survey_1_ids <- survey_1_ids[-which(is.na(survey_1_ids))]
survey_2_ids <- survey_2_ids[-which(is.na(survey_2_ids))]

total_resp <- length(c(survey_1_ids, survey_2_ids)) - length(intersect(survey_1_ids, survey_2_ids))
resp_1 <- length(setdiff(survey_1_ids, survey_2_ids))
resp_2 <- length(setdiff(survey_2_ids, survey_1_ids))
both <- length(intersect(survey_1_ids, survey_2_ids))

print(paste0("Total respondents: ", total_resp))
print(paste0("Responded to Survey 1 only: ", resp_1, " (", round(resp_1/total_resp*100, 1), "%)"))
print(paste0("Responded to Survey 2 only: ", resp_2, " (", round(resp_2/total_resp*100, 1), "%)"))
print(paste0("Responded to both surveys: ", both, " (", round(both/total_resp*100, 1), "%)"))

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
