
#################################################################################################
#################################################################################################
#################################################################################################

# Audrée Lemieux
# Updated on August 11, 2026

#################################################################################################

# Load libraries
library(readxl)
library(gtsummary)

# To modify
today <- "260811"
clinics_filename <- "/Users/username/Documents/Manuscripts/Final datasets used/260811_CPIN_MS1_DataCleaned_reordered.xlsx"
tab_name <- c("Survey 1 - Umbrella (cleaned)", "CPIN OLMC (cleaned)", "Survey 1 - ACHH (cleaned)", "Survey 2 - ACHH (cleaned)", "Survey 2 - ACHH (consent) (cle)", "Survey 2 - ACHH 2.0 (cleaned)", "Vaccine Hesitancy (cleaned)", "Vaccine Hesitancy - All c (cle)")
variables <- c("days_to_respond")

#################################################################################################
#################################################################################################

# Extract data
data_df <- NULL

for (i in 1:length(tab_name)){
  raw <- as.data.frame(read_xlsx(clinics_filename, sheet = tab_name[i]))
  
  # Combine in a df
  data_df <- rbind(data_df, cbind(
    survey = tab_name[i],
    days_to_respond = raw$days_to_respond
  ))
}
data_df <- as.data.frame(data_df)
data_df$days_to_respond <- as.numeric(data_df$days_to_respond)
data_df$days_to_respond2 <- data_df$days_to_respond

#################################################################################################

# Transform dates
data_df$days_to_respond2[which(data_df$days_to_respond == 1)] <- "1 day"
data_df$days_to_respond2[which(data_df$days_to_respond == 2)] <- "2 days"
data_df$days_to_respond2[which(data_df$days_to_respond == 3)] <- "3 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 4 & data_df$days_to_respond <= 7)] <- "Between 4 and 7 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 8 & data_df$days_to_respond <= 14)] <- "Between 8 and 14 days"
data_df$days_to_respond2[which(data_df$days_to_respond >= 15 & data_df$days_to_respond <= 30)] <- "Between 15 and 30 days"
data_df$days_to_respond2[which(data_df$days_to_respond > 30)] <- "More than 30 days"
data_df$days_to_respond2[is.na(data_df$days_to_respond)] <- "Could not be determined"

#################################################################################################

# Get table (by survey)
data_df |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df[which(data_df$survey == "CPIN Umbrella (cleaned)"),] |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df[which(data_df$survey == "CPIN OLMC (cleaned)"),] |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df[which(data_df$survey == "Survey 1 - ACHH (cleaned)"),] |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df[which(data_df$survey == "Survey 2 - ACHH (cleaned)" | data_df$survey == "Survey 2 - ACHH (consent) (cle)" | data_df$survey == "Survey 2 - ACHH 2.0 (cleaned)"),] |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

data_df[which(data_df$survey == "Vaccine Hesitancy (cleaned)" | data_df$survey == "Vaccine Hesitancy - All c (cle)"),] |>
  select('days_to_respond2') |>
  tbl_summary(digits = list(all_categorical() ~ c(0, 1)))

#################################################################################################
#################################################################################################

# q(save = "no")

#################################################################################################
#################################################################################################
#################################################################################################
