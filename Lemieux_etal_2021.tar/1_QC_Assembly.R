
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) for the quality control (QC) and the assembly de
# novo, or steps 1 and 2 of Figure S1. We used FastQC, Trimmomatic, and FastQC again for the QC, 
# then SPAdes, metaSPAdes, Trinity, and rnaSPAdes for the assembly.

### Repeat this step on each paired-end file (each replicate). ###

# Load the following modules in Unix (shell):
#   r/4.0.0
#   fastqc/0.11.8
#   trimmomatic/0.36
#   spades/3.13.1
#   trinity/2.9.0

# Make sure that the following files are in the working directory:
#   the raw data files (*fastq.gz)

#################################################################################################

                                        #############
                                        # 1. FastQC #
                                        #############

directory <- getwd()
out_files <- list.files(paste0(directory, "/"), pattern = "fastq.gz")
system(paste0("fastqc -t 5 ", out_files))

#################################################################################################

                                      ##################
                                      # 2. Trimmomatic #
                                      ##################

# Run Trimmomatic with the parameters used in the publication (see section 2.1). For more informa-
# tion: http://www.usadellab.org/cms/?page=trimmomatic
# Notes:
#   Replace **1** by: file name, forward read
#   Replace **2** by: file name, reverse read
#   Replace **3** by: first paired output (forward), *_R1_paired.fastq.gz
#   Replace **4** by: second paired output (reverse), *_R2_paired.fastq.gz
#   Replace **5** by: first unpaired output (forward), *_R1_unpaired.fastq.gz
#   Replace **6** by: second unpaired output (reverse), *_R2_unpaired.fastq.gz

system("
java -jar $EBROOTTRIMMOMATIC/trimmomatic-0.36.jar PE -threads 8 -phred33 \
# **1** **2** \
# **3** **4** \
# **5** **6** \
ILLUMINACLIP:adapters/TruSeq3-PE-2.fa:3:26:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:20 MINLEN:36 CROP:105 HEADCROP:15 AVGQUAL:20
")

#################################################################################################

                                          #############
                                          # 3. FastQC #
                                          #############

paired_files <- list.files(paste0(directory, "/"), pattern = "_paired.fastq.gz")
system(paste0("fastqc -t 5 ", paired_files))

#################################################################################################

                                    #######################
                                    # 4. Assembly de novo #
                                    #######################

# For more information (manuals):
#   SPAdes: http://cab.spbu.ru/files/release3.12.0/manual.html
#   metaSPAdes: http://cab.spbu.ru/files/release3.12.0/manual.html#meta
#   rnaSPAdes: http://cab.spbu.ru/files/release3.11.1/rnaspades_manual.html
#   Trinity: https://github.com/trinityrnaseq/trinityrnaseq/wiki
# Notes:
#   Replace **1** by: forward paired read
#   Replace **2** by: reverse paired read
#   Replace **3** by: output directory
#   Replace **4** by: max memory
#   Replace **5** by: CPU core number

# For the DNA-Seq data
system("spades.py -1 **1** -2 **2** -o **3**") # SPAdes
system("spades.py --meta -1 **1** -2 **2** -o **3**") # metaSPAdes

# For the RNA-Seq data
system("spades.py --rna -1 **1** -2 **2** -o **3**") # rnaSPAdes
system("spades.py --meta -1 **1** -2 **2** -o **3**") # metaSPAdes
system("Trinity --seqType fq --max_memory **4** --CPU **5**  --left **1** --right **2**") # Trinity

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
