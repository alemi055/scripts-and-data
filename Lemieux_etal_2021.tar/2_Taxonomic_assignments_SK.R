
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) for the taxonomic annotations at the superkingdom
# (SK) level with BLASTn, or step 3 of the Figure S1. 

### Repeat this step on each contig file (each replicate). ###
### Replace "sample_name" by the sample's name. ###

# Load the following modules in Unix (shell):
#   r/4.0.0
#   blast+/2.10.0

# Make sure that the following files are in the working directory:
#   the FASTA file (containing the assembled contigs)


library(ape)
library(seqinr)
library(dplyr)

#################################################################################################

                                  ##################################
                                  # 1. BLASTn against the nr/nt DB #
                                  ##################################

# # If not done already, download the formatted nr/nt DB from:
# system("wget ftp://ftp.ncbi.nlm.nih.gov/blast/db/nt*tar.gz")
# directory <- getwd()
# nt_files <- list.files(paste0(directory, "/"), pattern = "tar.gz")
# 
# for (i in 1:length(nt_files)){
#   system(paste0("tar -xvf ", nt_files[i]))
# }


# Run the BLASTn command in the directory containing the "nt" files
# It is suggested to split the FASTA file into shorter files (of 1,024 sequences, for instance).
# If the sequences take > 1 line :
tr <- read.FASTA("transcripts.fasta") # For rnaSPAdes, or "contigs.fasta" for metaSPAdes
write.fasta(sequences = as.character(tr), names = names(tr), file.out = "one_line.fasta",
            nbchar = length(tr[[1]]))
system(paste0("tr [:lower:] [:upper:] < one_line.fasta > one_upper.fasta")) # Convert all lower letters into upper letters
system(paste0("split -d -l 2048 rnaspades_transcripts.fasta")) # Split the file into smaller files of 1,024 sequences


# Run BLASTn with the parameters used in the publication (see section 2.1).
# Use array when possible.
# Notes:
#   Replace **1** by: path to directory containing the nr/nt DB
#   Replace **2** by: query file (file containing 1,024 sequences)
#   Replace **3** by: output file

system("blastn -num_threads 4 -task blastn -db **1**/nt -query **2** -out **3** -evalue 10e-20 -max_target_seqs 100 -outfmt \"7 qseqid sseqid sskingdoms staxids sscinames sblastnames scomnames pident bitscore evalue\"")

#################################################################################################

                                ############################
                                # 3. Read the BLAST output #
                                ############################

# All the sequences should be in a single file: use "cat" to concatenate in Unix (shell).
# All the BLASTn outputs should be in a single file: use "cat" to concatenate in Unix (shell).

# Make sure that the following files are in the working directory:
#   a single .fasta file containing the contig sequences, "sample_name_seq.fasta".
#   a single .out file containing the BLASTn outputs, "sample_name_outfmt_7.out".

directory <- getwd()
out_files <- list.files(paste0(directory, "/"), pattern = "outfmt_7")

seq_count <- 0
seq_name <- NULL
blast_tab <- blast_tmp <- NULL

for(i in rev(out_files)){
  print(paste0("Now doing ", i))
  ln <- NULL
  ln <- readLines(paste0(directory, "/", i))
  nbln <- length(ln)
  
  # we read line by line
  start_reading <- query_found <- 0
  for(j in 1:nbln){
    
    # new query?
    if(grepl("^\\# Query:", ln[j])){
      seq_count <- seq_count + 1
      seq_name[seq_count] <- unlist(strsplit(ln[j], " "))[3]
      blast_tmp <- NULL
    }
    
    # start reading
    if(grepl(" hits found", ln[j])){
      start_reading <- 1
    }else{
      # lines w/ blasts res
      if(start_reading & grepl("^[A-Z]", ln[j])){
        blast_tmp <- rbind(blast_tmp, ln[j])
      }
      # first line of next result: stop reading
      if(start_reading & grepl("^\\#", ln[j]) ){
        start_reading <- 0
        blast_tab[[seq_count]] <- blast_tmp
      }
      
    }
    
  }
  
}

save.image("parse_blast_sample_name.RData")


                                    #########################
                                    # Parse in tabular form #
                                    #########################

nseq <- length(seq_name)
blast_tabular <- NULL

for(i in 1:length(blast_tab)){
  if(!(i %% 1000)){
    print(paste0("Now doing ", i, " -- out of ", nseq))
  }
  tmp <- blast_tab[[i]]
  newline <- NULL
  if(length(tmp) > 0){
    for(j in 1:length(tmp)){
      curline <- Query_ID <- SK <- tax_ID <- PC_ID <- BS <- Species <- Evalue <- NULL
      curline <- tmp[j]
      curline_split <- unlist(strsplit(curline, "\\t"))
      Query_ID <- curline_split[1]
      SK 		<- curline_split[3]
      tax_ID	<- curline_split[4]
      Species	<- curline_split[5]
      PC_ID	<- curline_split[8]
      BS		<- curline_split[9]
      Evalue	<- curline_split[10]
      newline <- rbind(newline, cbind(Query_ID = Query_ID, Superkingdom = SK, Species = Species,
                                      Tax_ID = tax_ID, PC_ID = PC_ID, BitScore = BS, Evalue = Evalue))
    }
    
  }
  blast_tabular[[i]] <- newline
}

save.image("parse_blast_sample_name.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
