
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to refine the taxonomic assignments of the virus-
# es, or specificially step 4 of the Figure S1.

### Repeat this step on each RData file (each replicate). ###
### Replace "sample_name" by the sample's name. ###

# Load the following modules in Unix (shell):
#   r/4.0.0
#   blast+/2.10.0
#   emboss/6.6.0

# Make sure that the following files are in the working directory:
#   the "parse_blast_sample_name.RData" file.
#   a single .fasta file containing the contig sequences.


library(ape)
library(taxonomizr)

load("parse_blast_sample_name.RData")

#################################################################################################

                                ############################
                                # 1. Extract viral contigs #
                                ############################

# Get results as a proportion table
blast_results <- as.data.frame(do.call(rbind, blast_tabular)) # Write as a df

blast_table <- as.table(table(blast_results$Query_ID, blast_results$Superkingdom))
blast_table <- round(prop.table(blast_table, 1), 3)
blast_table <- as.data.frame(blast_table)
names(blast_table) <- c("Query_ID", "Superkingdom", "Prop_BLAST_res")


# Get all viral contigs
pos_vir <- which((blast_table$Superkingdom == "Viruses") & (blast_table$Prop_BLAST_res >= 0.95))
blast_table_vir <- blast_table[pos_vir,]
virus_contigs_ID <- as.character(blast_table_vir$Query_ID)


# Extract viral contigs
all_contigs <- read.FASTA("sample_name_seq.fasta")
all_contigs_names <- names(all_contigs)

all_contigs_names_clean <- NULL
for(i in 1:length(all_contigs_names)){
  all_contigs_names_clean[i] <- unlist(strsplit(all_contigs_names[i], " "))[1]
}

vir_contigs_pos <- which(all_contigs_names_clean %in% virus_contigs_ID)
write.FASTA(all_contigs[vir_contigs_pos], "sample_name_vir_contigs.fasta")

#################################################################################################

                                  ##################################
                                  # 2. BLASTn against the viral DB #
                                  ##################################

# # If not done already, download GenBank's viral DB from:
# system("wget ftp://ftp.ncbi.nlm.nih.gov/genbank/gbvrl*.seq.gz")
# directory <- getwd()
# vir_files <- list.files(paste0(directory, "/"), pattern = "seq.gz")
# 
# for (i in 1:length(nt_files)){
#   system(paste0("tar -xvf ", nt_files[i]))
# }
# 
# system("cat gbvrl*seq > genbank_viral.seq") # Concatenate into one file
# system("seqret genbank_viral.seq gbvrl.fasta") # Convert into a fasta file
# system("makeblastdb -in gbvrl.fasta -parse_seqids -title \"gbvrl\" -dbtype nucl") # Build the DB
# system("rm *seq.gz")


# Run BLASTn with the parameters used in the publication (see section 2.1).
# Use array when possible.
# Notes:
#   Replace **1** by: path to directory containing the gbvrl DB

system("blastn -num_threads 4 -task blastn -db **1**/gbvrl -query sample_name_vir_contigs.fasta -out sample_name_vir_blast.out -evalue 10e-20 -max_target_seqs 100 -outfmt \"7 qseqid sseqid sskingdoms staxids sscinames sblastnames scomnames pident bitscore evalue\"")

#################################################################################################

                                ############################
                                # 3. Read the BLAST output #
                                ############################

# All the sequences should be in a single file: use "cat" to concatenate in Unix (shell).
# All the BLASTn outputs should be in a single file: use "cat" to concatenate in Unix (shell).
# 
# Make sure that the following files are in the working directory:
#   a single .fasta file containing the contig sequences, "sample_name_vir_contigs.fasta".
#   a single .out file containing the BLASTn outputs, "sample_name_vir_blast.out".

# Import the viral contigs
directory <- getwd()
blast_file <- list.files(paste0(directory, "/"), pattern = "vir_blast.out")

seq_count <- 0
seq_name <- NULL
blast_tab <- blast_tmp <- NULL

for(i in rev(blast_file)){
  print(paste0("Now doing ", i))
  ln <- NULL
  ln <- readLines(paste0(directory, "/", i))
  nbln <- length(ln)
  
  # we read line by line
  start_reading <- query_found <- 0
  for(j in 1:nbln){
    
    # new query?
    if(grepl("^\\# Query:", ln[j])){
      seq_count <- seq_count + 1
      seq_name[seq_count] <- unlist(strsplit(ln[j], " "))[3]
      blast_tmp <- NULL
    }
    
    # start reading
    if(grepl(" hits found", ln[j])){
      start_reading <- 1
    }else{
      # lines w/ blasts res
      if(start_reading & grepl("^[A-Z]", ln[j])){
        blast_tmp <- rbind(blast_tmp, ln[j])
      }
      # first line of next result: stop reading
      if(start_reading & grepl("^\\#", ln[j]) ){
        start_reading <- 0
        blast_tab[[seq_count]] <- blast_tmp
      }
      
    }
    
  }
  
}

save.image("sample_name_extract_vir_lineage.Rdata")


                                    #########################
                                    # Parse in tabular form #
                                    #########################

nseq <- length(seq_name)
blast_tabular <- NULL

for(i in 1:length(blast_tab)){
  if(!(i %% 1000)){
    print(paste0("Now doing ", i, " -- out of ", nseq))
  }
  tmp <- blast_tab[[i]]
  newline <- NULL
  if(length(tmp) > 0){
    for(j in 1:length(tmp)){
      curline <- Query_ID <- accession <- NULL
      curline <- tmp[j]
      curline_split <- unlist(strsplit(curline, "\\t"))
      Query_ID <- curline_split[1]
      accession <- curline_split[3]
      newline <- rbind(newline, cbind(Query_ID = Query_ID, accession = accession))
    }
  }
  blast_tabular[[i]] <- newline
}

save.image("sample_name_extract_vir_lineage.Rdata")

#################################################################################################

                                ###########################
                                # 4. Get the full lineage #
                                ###########################

# Make sure that the file "accessionTaxa.sql" (next step) is in a central location, so that it does
# not need to be replicated for each project.
# In my case, it was located here: "/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql".
# The downloaded files might take up to 75G, so make sure that you have enough space.

prepareDatabase("/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql")


# For each contig, get the taxonomy of the HSPs
taxonomy_df <- NULL

for (i in 1:length(blast_tabular)){
  if (length(blast_tabular[[i]] > 0)){ # If there are hits
    blast_tabular[[i]] <- data.frame(blast_tabular[[i]])
    accessions_tmp <- taxonomy_tmp <- taxID_tmp <- NULL
    accessions_tmp <- unique(blast_tabular[[i]]$accession) # Get the accessions of the HSPs
    
    # Get the taxID
    taxID_tmp <- accessionToTaxa(accessions_tmp, "/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql",
                                 version = "base")
    taxID_tmp <- unique(taxID_tmp)
    
    #Get the taxonomy
    taxonomy_tmp <- getTaxonomy(taxID_tmp, "/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql")
    
    # Add the taxID and the contig name
    query_id <- strsplit(blast_tabular[[i]][,1], split = "_")
    query_id <- rep(paste0("NODE_", query_id[[1]][2]), length(query_id))
    newline <- cbind(query_id, taxID_tmp, taxonomy_tmp)
    
    taxonomy_df <- rbind(taxonomy_df, newline)
  }
}


# Remove sequences with missing values
taxonomy_df <- data.frame(taxonomy_df)
colnames(taxonomy_df)[2] <- "taxID"

na <- NULL
na <- which(is.na(taxonomy_df$taxID))
if (length(na) > 0){
  taxonomy_df <- taxonomy_df[-na,]
}


# Write the taxonomy into a csv file
write.csv(taxonomy_df, gsub("vir_blast.out", "virus_taxonomy.csv", blast_file), row.names = FALSE)

save.image("sample_name_extract_vir_lineage.Rdata")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
