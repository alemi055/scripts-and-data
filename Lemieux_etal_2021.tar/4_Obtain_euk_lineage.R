
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to obtain the taxonomic assignments of the euka-
# ryotes, or specificially step 5 of the Figure S1. 

### Repeat this step on each RData file (each replicate). ###
### Replace "sample_name" by the sample's name. ###

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following files are in the working directory:
#   the "parse_blast_sample_name.RData" file.
#   a single .fasta file containing the contig sequences.


library(ape)
library(dplyr)
library(taxonomizr)

load("parse_blast_sample_name.RData")

#################################################################################################

                              #################################
                              # 1. Extract eukaryotic contigs #
                              #################################

# Get results as a proportion table
blast_results <- as.data.frame(do.call(rbind, blast_tabular)) # Write as a df

blast_table <- as.table(table(blast_results$Query_ID, blast_results$Superkingdom))
blast_table <- round(prop.table(blast_table, 1), 3)
blast_table <- as.data.frame(blast_table)
names(blast_table) <- c("Query_ID", "Superkingdom", "Prop_BLAST_res")


# Get all eukaryotic contigs
pos_euk <- which((blast_table$Superkingdom == "Eukaryota") & (blast_table$Prop_BLAST_res >= 0.95))
blast_table_euk <- blast_table[pos_euk,]
euk_contigs_ID <- as.character(blast_table_euk$Query_ID)


# Extract eukaryotic contigs
all_contigs <- read.FASTA("sample_name_seq.fasta")
all_contigs_names <- names(all_contigs)

all_contigs_names_clean <- NULL
for(i in 1:length(all_contigs_names)){
  all_contigs_names_clean[i] <- unlist(strsplit(all_contigs_names[i], " "))[1]
}

euk_contigs_pos <- which(all_contigs_names_clean %in% euk_contigs_ID)
write.FASTA(all_contigs[euk_contigs_pos], "sample_name_euk_contigs.fasta")

#################################################################################################

                                  ##################################
                                  # 2. Find the eukaryotic contigs #
                                  ##################################

directory <- getwd()
fasta_file <- list.files(paste0(directory, "/"), pattern = "euk_contigs.fasta")
euk_fasta <- read.FASTA(fasta_file)

contig_names <- NULL
contig_names <- names(euk_fasta)


# Name the blast_tabular lists as their sequence name
names(blast_tabular) <- seq_name[1:length(blast_tabular)]

#################################################################################################

                                ###########################
                                # 3. Get the full lineage #
                                ###########################

# # Make sure that the file "accessionTaxa.sql" (next step) is in a central location, so that it does
# # not need to be replicated for each project.
# # In my case, it was located here: "/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql".
# # The downloaded files might take up to 75G, so make sure that you have enough space.
# 
# prepareDatabase("/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql")


# Extract species lineages
euk_contig_df <- NULL

for (i in contig_names){
  if (!is.null(blast_tabular[[i]])){
    tmp_df <- tax_IDs <- tmp <- newline <- tmp_tax <- tmp_pos <- NULL
    tmp_df <- data.frame(blast_tabular[[i]])
    
    # Only keep rows whose E-values < 1e-100. If > 12 rows, only keep the first 12
    tmp_df$Evalue <- as.numeric(tmp_df$Evalue)
    tmp_df <- dplyr::filter(tmp_df, tmp_df$Evalue < 1e-100)
    if (nrow(tmp_df) > 12){
      tmp_df <- tmp_df[1:12,]
    }
    
    tmp_df <- tmp_df[, -c(2, 3, 5, 6, 7)]
    
    # Find and extract tax IDs containing ";"
    tmp_pos <- grep(";", tmp_df$Tax_ID)
    if (length(tmp_pos) > 0){
      tmp_tax <- unlist(strsplit(tmp_df$Tax_ID[tmp_pos], ";"))
      tmp_df <- tmp_df[-tmp_pos,]
      tmp_df <- rbind(tmp_df, cbind(Query_ID = rep(tmp_df$Query_ID[1], length(tmp_tax)), Tax_ID = tmp_tax))
    }
    
    # Get each tax ID only once
    tax_IDs <- unique(tmp_df$Tax_ID)
    
    # Create a data frame w/ contig name, taxID and species lineages
    if (length(tax_ID) > 0){
      tmp <- getTaxonomy(tax_IDs, "/home/alemi055/scratch/ete2020/taxonomy_db/accessionTaxa.sql")
      if (!is.null(tmp)){
        newline <- cbind(i, tax_IDs, tmp)
        euk_contig_df <- rbind(euk_contig_df, newline)
      }
    }
  }
}

euk_contig_df <- data.frame(euk_contig_df)
colnames(euk_contig_df)[1:2] <- c("contig_name", "tax_id")


# Remove all the species that are "uncultured"
for (i in 1:nrow(euk_contig_df)){
  uncultured_pos <- NULL
  uncultured_pos <- grep("[Uu]ncultured ", euk_lin_df[i,]$species)
  if (length(uncultured_pos) > 0){
    euk_lin_df[[i]] <- euk_lin_df[[i]][-uncultured_pos, ]
  }
}

write.csv(euk_contig_df, "sample_name_euk_taxonomy.csv", row.names = FALSE)

save.image("sample_name_euk_lineage.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
