
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to obtain the Trees of Life (ToL) of the viruses
# and the eukaryotic hosts (beginning of step 6 of the Figure S1).

### Replace "sample_name" by the sample's name. ###

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following files are in the working directory:
#   all the "virus_taxonomy.csv" files for one specific sampling site.
#   all the "euk_taxonomy.csv" files for one specific sampling site


library(ape)
library(dplyr)
library(taxize)
library(rentrez)

#################################################################################################

                                ###########################
                                # 1. Obtain the viral ToL #
                                ###########################

# Import the "virus_taxonomy.csv" files
directory <- getwd()
vir_files <- list.files(paste0(directory, "/"), pattern = "virus_taxonomy.csv")
vir_taxonomy <- NULL

for (i in 1:length(vir_files)){
  tmp <- read.csv(vir_files[i])
  tmp <- tmp[, -1]
  vir_taxonomy <- rbind(vir_taxonomy, tmp) # Combine the data of the replicates
}

vir_taxonomy <- distinct(vir_taxonomy) # Only keep each virus once
vir_taxIDs <- unique(vir_taxonomy$taxID)


# Set API key. Get it by creating a NCBI account (if not done already):
# https://www.ncbi.nlm.nih.gov/myncbi/
# Notes:
#   Replace **1** by: API key

set_entrez_key("**1**")

# Generate tree from taxIDs
virus_class <- taxize::classification(vir_taxIDs, db = "ncbi")
virus_classtree <- taxize::class2tree(virus_class)
virus_tree <- virus_classtree$phylo
write.tree(virus_classtree$phylo, "virus_tree_sample_name.phy") 

#################################################################################################

                            ################################
                            # 2. Obtain the eukaryotic ToL #
                            ################################

# Import the "euk_taxonomy.csv" files
euk_files <- list.files(paste0(directory, "/"), pattern = "euk_taxonomy.csv")
euk_taxonomy <- NULL

for (i in 1:length(euk_files)){
  tmp <- read.csv(euk_files[i])
  tmp <- tmp[, -1]
  euk_taxonomy <- rbind(euk_taxonomy, tmp) # Combine the data of the replicates
}

euk_taxonomy <- distinct(euk_taxonomy) # Only keep each host once
euk_taxIDs <- unique(euk_taxonomy$tax_id)


# Simplify the eukaryotic tree - only keep the hosts that have a known association to a virus
# Get the Viral-Host DB from: https://www.genome.jp/virushostdb/

virushostdb <- "virushostdb.tsv"
db <- read.table(virushostdb, sep = "\t", header = TRUE, fill = TRUE, quote = "\"")
match_taxID <- NULL
count <- 0

for (i in 1:length(vir_taxIDs)){ # Find the virus in the db
  tmp <- host_info <- NULL
  tmp <- db[db$virus.tax.id == vir_taxIDs[i],]
  if (nrow(tmp) > 0){ # If the virus has at least 1 host
    host_info <- tmp$host.tax.id
    for (j in 1:length(host_info)){ # Are the hosts found in our data? If so, store it in "match_taxID"
      if (host_info[j] %in% euk_taxIDs){
        count <- count + 1
        match_taxID[count] <- host_info[j]
      }
    }
  }
}
match_taxID <- unique(match_taxID)


# Generate tree from taxIDs
euk_class <- taxize::classification(match_taxID, db = "ncbi")
euk_classtree <- taxize::class2tree(euk_class)
euk_tree <- euk_classtree$phylo
write.tree(euk_classtree$phylo, "euk_tree_sample_name.phy") 

#################################################################################################

                                ###############################
                                # 3. Create the binary matrix #
                                ###############################

# Clean the environment
rm(euk_class, euk_classtree, euk_taxonomy, virus_class, virus_classtree, vir_taxonomy)
rm(count, euk_files, host_info, i, j, vir_files)


# Get the names of the viruses/hosts
euk_names <- euk_tree$tip.label
vir_names <- virus_tree$tip.label


# Build the binary matrix
nhosts <- length(match_taxID)
HS <- NULL
HS <- cbind(HS, euk_names)
HS <- as.data.frame(HS)

for (i in 1:length(vir_names)){
  tmp <- match <- tmp_host <- pos <- NULL
  tmp <- rep(0, nhosts)
  # match <- grep(vir_names[i], db$virus.name)
  match <- which(db$virus.name == vir_names[i])
  if (length(match) > 0){ # Is the virus linked to a host?
    tmp_host <- db$host.name[match]
    tmp_host <- unique(tmp_host)
    pos <- which(euk_names %in% tmp_host)
    if (length(pos) > 0){ # For each known virus-host association, put a "1"
      tmp[pos] <- 1 
    }
  }
  HS <- cbind(HS, tmp)
  colnames(HS)[ncol(HS)] <- vir_names[i]
}

row.names(HS) <- HS$euk_names
HS <- HS[, -1]
write.table(HS, "HS_matrix_sample_name.txt")

save.image("tol_sample_name.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
