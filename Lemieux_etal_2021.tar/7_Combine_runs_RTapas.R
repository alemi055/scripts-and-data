
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to combine the results of each run of Random Ta-
# Pas. 

### Replace "sample_name" by the sample's name. ###

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following is in the working directory:
#   the ".RData" file for one specific sampling site (run #1).
#   the "_2.RData" file for one specific sampling site (run #2).
#   the "_3.RData" file for one specific sampling site (run #3).

#################################################################################################

# BEFOREHAND! Make sure that "i" is not loaded in any of the RData files. If yes, the R loop will
# not work.

# Load all the RData files
directory <- getwd()
rdata_files <- list.files(paste0(directory, "/"), pattern = ".RData")

GiniMGD_lst <- list()
GiniMPA_lst <- list()

for (i in 1:3){
  current_files <- ls()
  load(rdata_files[i])
  rm(list=setdiff(ls(), c(current_files, "GiniMGD", "GiniMPA"))) # Clean environment
  
  GiniMGD_lst[[i]] <- GiniMGD # Store GD and PACo values
  GiniMPA_lst[[i]] <- GiniMPA
  rm(GiniMGD, GiniMPA) # Remove GiniMGD and GiniMPA
}


# Combine values
GiniMGD_sample_name <- as.numeric(unlist(GiniMGD_lst))
GiniMPA_sample_name <- as.numeric(unlist(GiniMPA_lst))

rm(list=setdiff(ls(), c("GiniMGD_sample_name", "GiniMPA_sample_name"))) # Clean environment

#################################################################################################

# Store the data in a data frame
sample_name_df <- NULL

tmp <- NULL # GD
tmp <- data.frame(cbind(analysis = rep("GD", 3000), site = rep("sample_site", 3000), gini = GiniMGD_sample_name))
sample_name_df <- rbind(sample_name_df, tmp)

tmp <- NULL # PACo
tmp <- data.frame(cbind(analysis = rep("PACo", 3000), site = rep("sample_site", 3000), gini = GiniMPA_sample_name))
sample_name_df <- rbind(sample_name_df, tmp)

sample_name_df$gini <- as.numeric(sample_name_df$gini)
rm(tmp, GiniMGD_sample_name, GiniMPA_sample_name)

save.image("gini_sample_name.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
