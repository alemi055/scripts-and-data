
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to visualize the proportions of RNA/DNA viral fa-
# milies, specifically for Figure 1.

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following files are in the working directory:
#   the "virus_taxonomy.csv" files for one specific sampling site


library(tidyverse)
library(ggpubr)

#################################################################################################

                            #####################################
                            # 1. Combine the taxonomy.csv files #
                            #####################################

### Repeat this step on each sampling site (we're combining the replicates). ###

# Import the "virus_taxonomy.csv" files
assembly <- getwd()
vir_files <- list.files(paste0(assembly, "/"), pattern = "virus_taxonomy.csv")

family_gen_file <- "family_genome.txt"
family_genome <- read.table(family_gen_file, header = TRUE, sep = "\t")
family_genome$genome <- factor(family_genome$genome, levels = c("ds DNA", "ds RNA", "ss RNA (-)", "ss RNA (+)"))
genome <- c("ds DNA", "ds RNA", "ss RNA (-)", "ss RNA (+)", "Unclassified ss RNA")

vir_taxonomy <- NULL
for (i in 1:length(vir_files)){
  tmp <- read.csv(vir_files[i])
  tmp <- tmp[, -1]
  vir_taxonomy <- rbind(vir_taxonomy, tmp)
}


tmp_df <- as.data.frame(table(vir_taxonomy$family))
colnames(tmp_df)[1] <- "family"

genomes <- NULL
for (i in 1:nrow(tmp_df)){
  tmp <- NULL
  tmp <- as.character(family_genome$genome[family_genome$family == tmp_df$family[i]])
  genomes <- rbind(genomes, tmp)
}

fam_table <- cbind(tmp_df, genome = genomes)
fam_table <- fam_table[order(fam_table$genome),]


rm(list = setdiff(ls(), "vir_taxonomy"))
save.image("vir_taxonomy.RData")

#################################################################################################

                            ##################################
                            # 2. Create the circular barplot #
                            ##################################

# Script inspired from Holtz (2018): https://www.r-graph-gallery.com/297-circular-barplot-with-groups.html

### Repeat this step on each sampling site (we're combining the replicates). ###

# Create figure for one specific site
tmp <- data.frame(table(vir_taxonomy$family))
data <- data.frame(family = tmp$Var1, freq = tmp$Freq)
data$freq <- log10(data$freq) # Get the log (base 10) of the frequency
data <- cbind(site = rep("sample_name", nrow(data)), data)


# Reformat "data"
data$site <- as.character(data$site)
data$family <- as.character(data$family)
data$freq <- as.numeric(data$freq)


# Add genome information
data$genome <- as.character(data$family)
for (i in 1:nrow(data)){
  fam <- gen <- NULL
  fam <- as.character(data$family[i])
  gen <- family_genome$genome[family_genome$family == fam]
  
  data$genome[i] <- gsub(fam, gen, data$genome[i])
}


# Is an unclassified virus present in this site?
unc_vir <- which(data$genome == "Unclassified ss RNA")

if (length(unc_vir) > 0){ # Remove unclassified virus
  data <- data[-unc_vir, ]
  levels(data$genome) <- unique(data$genome)
  data$genome <- factor(data$genome, levels = genome)
}else{
  # data$genome <- factor(data$genome, levels = genome[1:4])
  data$genome <- factor(data$genome, levels = genome[c(1, 2, 4)])
}


# Set a number of 'empty bar' to add at the end of each group
empty_bar <- 3
to_add <- data.frame(matrix(NA, empty_bar*nlevels(data$genome), ncol(data)))
colnames(to_add) <- colnames(data)
to_add$genome <- rep(levels(data$genome), each=empty_bar)
data <- rbind(data, to_add)
data <- data %>% arrange(genome)
data$id <- seq(1, nrow(data))


# Get the name and the y position of each label
label_data <- data
number_of_bar <- nrow(label_data)
angle <- 90 - 360 * (label_data$id-0.5) /number_of_bar # I substract 0.5 because the letter must have the angle of the center of the bars. Not extreme right(1) or extreme left (0)
label_data$hjust <- ifelse( angle < -90, 1, 0)
label_data$angle <- ifelse(angle < -90, angle+180, angle)


# Prepare a data frame for base lines
grid_data <- NULL

for (i in 1:nrow(data)){
  if(is.na(data$site[i])){ # Is it NA?
    if(!is.na(data$site[i - 1]) & is.na(data$site[i + 1])){
      tmp <- NULL
      tmp <- cbind(genome = as.character(data$genome[i]), end = i + 2, start = i)
      grid_data <- rbind(grid_data, tmp)
    }
  } 
}

grid_data <- as.data.frame(grid_data)


# Choose the order
family_genome <- arrange(family_genome, family_genome$genome)

# Create function "ColourPalleteMulti"
ColourPalleteMulti <- function(df, group, subgroup){

  # Find how many colour categories to create and the number of colours in each
  categories <- aggregate(as.formula(paste(subgroup, group, sep="~" )), df, function(x) length(unique(x)))
  family.start <- (scales::hue_pal(l = 100)(nrow(categories))) # Set the top of the colour pallete
  family.end  <- (scales::hue_pal(l = 40)(nrow(categories))) # set the bottom

  # Build Colour pallette
  colours <- unlist(lapply(1:nrow(categories),
                           function(i){
                             colorRampPalette(colors = c(family.start[i], family.end[i]))(categories[i,2])}))
  return(colours)
}


# Build the colours pallete
all_colours <- ColourPalleteMulti(family_genome, "genome", "family")
colours_df <- cbind(family_genome, all_colours)
data$colours <- data$family

for (i in 1:nrow(data)){ # Replace the family by the colour
  if (!is.na(data$colours[i])){
    tmp <- fam <- NULL
    fam <- data$family[i]
    tmp <- colours_df$all_colours[colours_df$family == fam]
    data$colours[i] <- gsub(data$colours[i], tmp, data$colours[i])
  }
}

# Alphabetic order of the families
tmp_cols <- NULL
tmp_cols <- data[, c(2,5)]
tmp_cols$family <- as.character(tmp_cols$family)
tmp_cols <- tmp_cols[order(tmp_cols$family),]
colours_soil <- unlist(tmp_cols$colours) # Get the colours for that order

# Make the plot
barplot <- ggplot(data, aes(x=as.factor(id), y = freq)) + # Do the plot
  geom_bar(aes(fill=family), stat="identity", alpha=0.5, show.legend = TRUE) +
  scale_fill_manual(values = colours_soil) +
  
  # Add a val=1/2/3/4 lines.
  geom_segment(data=grid_data, aes(x = end, y = 4, xend = start, yend = 4), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) +
  geom_segment(data=grid_data, aes(x = end, y = 3, xend = start, yend = 3), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) +
  geom_segment(data=grid_data, aes(x = end, y = 2, xend = start, yend = 2), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) +
  geom_segment(data=grid_data, aes(x = end, y = 1, xend = start, yend = 1), colour = "grey", alpha=1, size=0.3 , inherit.aes = FALSE ) +
  
  # Add text showing the value of each 2/4 lines
  annotate("text", x = rep(max(data$id),2), y = c(2, 4), label = c(expression(10^{2}), expression(10^{4})) , color="grey", size=3 , angle=0, hjust=1) +
  
  geom_bar(aes(x=as.factor(id), y=freq, fill=family), stat="identity", alpha=0.5) +
  ylim(-2.5,5) +
  theme_minimal() +
  theme(
    axis.text = element_blank(),
    axis.title = element_blank(),
    panel.grid = element_blank(),
    plot.margin = unit(rep(-1,4), "cm") 
  ) +
  coord_polar()

barplot


pdf("barplot.pdf", height = 6, width = 6)
barplot
dev.off()

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
