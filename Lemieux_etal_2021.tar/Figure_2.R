
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to visualize the gini values computed by Random
# TaPas, or specifically for Figure 2.

# Load the following modules in unix (shell):
#   r/4.0.0

# Make sure that the following is in the working directory:
#   all the "gini_sample_name.RData" files (for all the sampling sites)

library(ggplot2)
library(dunn.test)
library(gridExtra)

##################################################################################################

                                        ###################
                                        # 1. Control site #
                                        ###################

# Load all the RData files
load("gini_RS3.RData") # Load soil sample
load("gini_S5.RData") # Load lake sediments sample
data_C <- rbind(RS3_df, S5_df)
rm(RS3_df, S5_df)


# Create barplot for GD
boxplot_C_GD <- ggplot(data_C[data_C$analysis == "GD",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "Normalized Gini coefficient (G*)\n", x = "\nGD") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        # axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_C_GD


# Create barplot for PACo
boxplot_C_PA <- ggplot(data_C[data_C$analysis == "PACo",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "", x = "\nPACo") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_C_PA


# Combined plots
C_plots <- grid.arrange(boxplot_C_GD, boxplot_C_PA, ncol = 2)

save.image("gini_combined_plots.RData")

##################################################################################################

                                      ########################
                                      # 2. Low runoff volume #
                                      ########################

# Load all the RData files
load("gini_BS3.RData") # Load soil sample
load("gini_S4.RData") # Load lake sediments sample
data_L <- rbind(BS3_df, S4_df)
rm(BS3_df, S4_df)


# Create barplot for GD
boxplot_L_GD <- ggplot(data_L[data_L$analysis == "GD",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "", x = "\nGD") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        # axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_L_GD


# Create barplot for PACo
boxplot_L_PA <- ggplot(data_L[data_L$analysis == "PACo",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "", x = "\nPACo") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_L_PA


# Combined plots
L_plots <- grid.arrange(boxplot_L_GD, boxplot_L_PA, ncol = 2)

save.image("gini_combined_plots.RData")

##################################################################################################

                                        #########################
                                        # 3. High runoff volume #
                                        #########################

# Load all the RData files
load("gini_AS3.RData") # Load soil sample
load("gini_S3.RData") # Load lake sediments sample
data_H <- rbind(AS3_df, S3_df)
rm(AS3_df, S3_df)


# Create barplot for GD
boxplot_H_GD <- ggplot(data_H[data_H$analysis == "GD",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "", x = "\nGD") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        # axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_H_GD


# Create barplot for PACo
boxplot_H_PA <- ggplot(data_H[data_H$analysis == "PACo",], aes(x = site, y = gini)) +
  geom_boxplot() +
  ylim(0.61, 0.81) + # Values might change. Use the max/min of for all plots
  labs(y = "", x = "\nPACo") +
  theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        axis.text.y = element_blank(),
        axis.title = element_text(size = 13))
boxplot_H_PA


# Combined plots
H_plots <- grid.arrange(boxplot_H_GD, boxplot_H_PA, ncol = 2)

save.image("gini_combined_plots.RData")

##################################################################################################

# Combine all plots
pdf("combined_boxplots.pdf", height = 4, width = 12)
grid.arrange(C_plots, L_plots, H_plots, ncol = 3)
dev.off()


# Pairwise Wilcoxon test
data <- rbind(data_H, data_L, data_C)
data$sample <- paste0(data$analysis, ".", data$site)

sink("dunn_test_results.txt")
dunn.test(data$gini, data$sample, method = "bh")
sink()

#################################################################################################
#################################################################################################


q("no")


#################################################################################################
#################################################################################################
#################################################################################################
