
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to visualize the taxonomic annotations at the su-
# perkingdom level of the contigs generated (using the 95% consensus). Specifically, for Figure S5.

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following files are in the working directory:
#   a .txt file containing the frequency of each SK (per sample)

library(ggplot2)

#################################################################################################

# From the "Table_S5.R" file, you should have obtained multiple tables (*.csv). For each replicate,
# calculate the averages to obtain a frequency of each SK/sample.

                                          #################
                                          # Load the data #
                                          #################

raw_data <- read.table("tax_proportions.txt", header = TRUE)
samples <- c("AS3", "BS3", "RS3", "S3", "S4", "S5")
article_name <- c("H", "L", "C", "H", "L", "C")
SK <- c("Archaea", "Bacteria", "Eukaryota", "Viruses", "Other")


# Create a df
data_lst <- list()
for (i in c("RNA", "DNA")){
  tmp <- NULL
  tmp <- raw_data[raw_data$nucleic_acid == i,]
  
  for (j in samples){
    newline <- NULL
    newline <- tmp[tmp$sample == j,]
    data_lst[[i]][[j]] <- newline
  }
}


# Get the proportions (in %) of the SK
SK_prop <- list()

for (i in c("RNA", "DNA")){
  for (j in samples){
    tmp <- NULL
    tmp <- data.frame(data_lst[[i]][[j]])
    tmp <- tmp[, 4:8]/tmp[,9]*100
    
    SK_prop[[i]][[j]] <- tmp
  }
}


# Get the average proportions for each nucleic acid. Reformat the data.
avg_prop <- NULL

for (i in c("RNA", "DNA")){
  for (j in samples){
    tmp <- NULL
    tmp <- data.frame(SK_prop[[i]][[j]])
    tmp <- colMeans(tmp)
    
    if(j == "AS3" | j == "BS3" | j == "RS3"){
      type <- NULL
      type <- "Soil"
      for (k in 1:5){
        avg_prop <- rbind(avg_prop, cbind(i, j, type, SK[k], tmp[k]))
      }
    }
    
    if(j == "S3" | j == "S4" | j == "S5"){
      type <- NULL
      type <- "Lake"
      for (k in 1:5){
        avg_prop <- rbind(avg_prop, cbind(i, j, type, SK[k], tmp[k]))
      }
    }
  }
}

avg_prop <- data.frame(avg_prop)  
colnames(avg_prop) <- c("nuc_acid", "sample", "type", "superkingdom", "prop")
avg_prop$prop <- as.numeric(avg_prop$prop)


# Substitute the sample name for the "litterature name"
for (i in 1:6){
  avg_prop$sample <- gsub(samples[i], article_name[i], avg_prop$sample)
}


# Substitute "Lake" for "Sediments"
avg_prop$type <- gsub("Lake", "Sediments", avg_prop$type)

#################################################################################################

                                    ######################
                                    # Create the barplot #
                                    ######################

# Create the barplot
# Choose the order
avg_prop$sample <- factor(avg_prop$sample, levels = c("C", "L", "H"))
avg_prop$type <- factor(avg_prop$type, levels = c("Soil", "Sediments"))
avg_prop$nuc_acid <- factor(avg_prop$nuc_acid, levels = c("DNA", "RNA"))
avg_prop$superkingdom <- factor(avg_prop$superkingdom, levels = c("Archaea", "Bacteria", "Eukaryota", "Viruses", "Other"))


# Create barplot
barplot <- ggplot(data = avg_prop, aes(fill = superkingdom, y = prop, x = sample)) +
  geom_bar(position = "fill", stat = "identity") +
  facet_grid(nuc_acid ~ type, scales = "free")


# Ajust axis and background
barplot <- barplot + theme_bw() +
  theme(strip.text.x = element_text(size = 12),
        axis.text = element_text(size = 11),
        axis.title = element_text(size = 13),
        legend.text = element_text(size = 8)) +
  labs(y = "Proportions (%)\n", x = "\nSample", fill = "Superkingdoms") +
  scale_y_continuous(labels =  function(x) paste0(x*100),  breaks = seq(0, 1, by = 0.2))


# Ajust colors
barplot <- barplot + scale_fill_manual(values = c("Archaea" = "#F8766D", "Bacteria" = "#A3A500", "Eukaryota" = "#00BFC4", "Viruses" = "#C77CFF", "Other" = "Dark grey"))


pdf("210328_barplot.pdf", width = 6, height = 4)
barplot
dev.off()

save.image("Figure_S5.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
