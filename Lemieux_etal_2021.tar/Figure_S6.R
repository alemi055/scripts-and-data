
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to visualize the gini values computed by Random
# TaPas, or specifically for Figure S6 (PACo).

# Load the following modules in unix (shell):
#   r/4.0.0

# Make sure that the following is in the working directory:
#   all the "gini_sample_name.RData" files (for all the sampling sites)

library(ggplot2)
library(dunn.test)
library(gridExtra)

load("210607_residual_analysis.RData")

##################################################################################################

# # To create the "residual_analysis.RData" file:
# # Load each RTaPas file for each sampling site (do it for each run: all the samples for run #1, ...)
# # Take the PACO.AV value and rename it. Store it in a list titled data_lst_**# of run**.
# # Do this 3 times or for whichever number of Random TaPas runs you decided.
# # You should have # of "data_lst" = the number of runs you did.
# # 
# # Finish with something like:
# samples <- c("C-Soil", "L-Soil", "H-Soil", "C", "L1", "H1")
# names(data_lst_3) <- samples
# 
# save.image("210607_residual_analysis.RData")

# # To create the dfs, do something like:
# data_df_soil <- NULL
# 
# for (i in 1:3){
#   tmp_1 <- tmp_2 <- tmp_3 <- NULL
#   tmp_1 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_1[[i]]), type = "max"), cbind(values = min(data_lst_1[[i]]), type = "min")))
#   tmp_2 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_2[[i]]), type = "max"), cbind(values = min(data_lst_2[[i]]), type = "min")))
#   tmp_3 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_3[[i]]), type = "max"), cbind(values = min(data_lst_3[[i]]), type = "min")))
#   data_df_soil <- rbind(data_df_soil, tmp_1, tmp_2, tmp_3)
# }
# 
# data_df_soil <- as.data.frame(data_df_soil)
# class(data_df_soil$values) <- "numeric"
# 
# data_df_soil$sample <- factor(data_df_soil$sample, levels = c("C-Soil", "L-Soil", "H-Soil"))
#
#
# data_df_lake <- NULL
# 
# for (i in 4:6){
#   tmp_1 <- tmp_2 <- tmp_3 <- NULL
#   tmp_1 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_1[[i]]), type = "max"), cbind(values = min(data_lst_1[[i]]), type = "min")))
#   tmp_2 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_2[[i]]), type = "max"), cbind(values = min(data_lst_2[[i]]), type = "min")))
#   tmp_3 <- cbind(sample = samples[i], rbind(cbind(values = max(data_lst_3[[i]]), type = "max"), cbind(values = min(data_lst_3[[i]]), type = "min")))
#   data_df_lake <- rbind(data_df_lake, tmp_1, tmp_2, tmp_3)
# }
# 
# data_df_lake <- as.data.frame(data_df_lake)
# class(data_df_lake$values) <- "numeric"
# 
# data_df_lake$sample <- factor(data_df_lake$sample, levels = c("C", "L1", "H1"))


soil_plot <- ggplot(data = data_df_soil) +
  aes(x = sample, y = values, colour = type) +
  geom_point() +
  theme_bw() +
  labs(x = "", y = "Residuals", colour = "")

lake_plot <- ggplot(data = data_df_lake) +
  aes(x = sample, y = values, colour = type) +
  geom_point() +
  theme_bw() +
  labs(x = "Sampling site", y = "Residuals", colour = "")

save.image("210607_residual_analysis.RData")


pdf("residuals_plot.pdf", height = 6, width = 4)
grid.arrange(soil_plot, lake_plot, ncol = 1, nrow = 2)
dev.off()


##########################################
# ANOVA - non parametric: Kruskal-Wallis #
##########################################

sink("210607_kruskal_wallis_test.txt")

paste("Soil - min")
kruskal.test(values ~ sample, data = data_df_soil[data_df_soil$type == "min",])
paste("Dunn's test: soil - min")
dunn.test(data_df_soil[data_df_soil$type == "min",]$values, data_df_soil[data_df_soil$type == "min",]$sample, method = "BH")

paste("Soil - max")
kruskal.test(values ~ sample, data = data_df_soil[data_df_soil$type == "max",])
paste("Dunn's test: soil - max")
dunn.test(data_df_soil[data_df_soil$type == "max",]$values, data_df_soil[data_df_soil$type == "max",]$sample, method = "BH")

paste("Lake sediments - min")
kruskal.test(values ~ sample, data = data_df_lake[data_df_lake$type == "min",])
paste("Dunn's test: Lake sediments - min")
dunn.test(data_df_lake[data_df_lake$type == "min",]$values, data_df_lake[data_df_lake$type == "min",]$sample, method = "BH")

paste("Lake sediments - max")
kruskal.test(values ~ sample, data = data_df_lake[data_df_lake$type == "max",])
paste("Dunn's test: Lake sediments - max")
dunn.test(data_df_lake[data_df_lake$type == "max",]$values, data_df_lake[data_df_lake$type == "max",]$sample, method = "BH")

sink()

#################################################################################################
#################################################################################################


q("no")


#################################################################################################
#################################################################################################
#################################################################################################

