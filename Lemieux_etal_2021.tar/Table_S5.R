
#################################################################################################
#################################################################################################
#################################################################################################

# This script was used in Lemieux et al. (2021) to visualize the taxonomic annotations at the su-
# perkingdom level of the contigs generated (using the 95% consensus). Specifically, for Table S5.

# Run this file on each replicate, and calculate averages on each replicate to obtain a proportion
# of each SK/sample.

# Load the following modules in Unix (shell):
#   r/4.0.0

# Make sure that the following files are in the working directory:
#   the "parse_blast_spades.RData" file.
#   a single .fasta file containing the contig sequences, "*seq.fasta".


library(ape)
library(dplyr)
library(ggplot2)
library(scales)

load("parse_blast_spades.RData")

#################################################################################################

                                    ############################
                                    # Determine a SK consensus #
                                    ############################

# Get results as a proportion table
blast_results <- as.data.frame(do.call(rbind, blast_tabular)) # Write as a df

blast_table <- as.table(table(blast_results$Query_ID, blast_results$Superkingdom))
blast_table <- round(prop.table(blast_table, 1), 3)
blast_table <- as.data.frame(blast_table)
names(blast_table) <- c("Query_ID", "Superkingdom", "Prop_BLAST_res")


# Create a vector for each SK consensus (95% consensus)
classified_Archaea <- which((blast_table$Superkingdom == "Archaea") & (blast_table$Prop_BLAST_res >= 0.95))
classified_Bacteria <- which((blast_table$Superkingdom == "Bacteria") & (blast_table$Prop_BLAST_res >= 0.95))
classified_Eukaryota <- which((blast_table$Superkingdom == "Eukaryota") & (blast_table$Prop_BLAST_res >= 0.95))
classified_Viruses <- which((blast_table$Superkingdom == "Viruses") & (blast_table$Prop_BLAST_res >= 0.95))


# All classified: Archaea, Bacteria, Eukaryota and Viruses
pos_all_classified <- c(classified_Archaea, classified_Bacteria, classified_Eukaryota, classified_Viruses)
blast_table_classified <- blast_table[pos_all_classified,]
classified_contigs_ID <- as.character(blast_table_classified$Query_ID)


# Find the "other" contigs
all <- which(blast_table$Prop_BLAST_res >= 0)
blast_table_all <- blast_table[all,]
all_contigs_ID <- unique(as.character(blast_table_all$Query_ID))

other_contigs_ID <- all_contigs_ID[-pmatch(classified_contigs_ID, all_contigs_ID)]

# Extract the "other" contigs
all_contigs <- read.FASTA("spades_seq.fasta")
all_contigs_names <- names(all_contigs)

all_contigs_names_clean <- NULL
for(i in 1:length(all_contigs_names)){
  all_contigs_names_clean[i] <- unlist(strsplit(all_contigs_names[i], " "))[1]
}

other_contigs_pos <- which(all_contigs_names_clean %in% other_contigs_ID)

blast_table_other <- blast_table[other_contigs_pos,]
blast_table_other$Superkingdom <- rep("Other", length(blast_table_other[,1]))


## Get a data frame containing all the SK consensus and the "others"
SK_consensus_df <- rbind(blast_table_classified, blast_table_other)

save.image("barplot_spades.RData")

#################################################################################################

                                    ##########################
                                    # Create a summary table #
                                    ##########################

# Create a dataset
SK_proportions <- count(SK_consensus_df, Superkingdom)
SK_proportions <- cbind(rep("BS3-3", 5), SK_proportions)
names(SK_proportions) <- c("Sample", "Superkingdom", "Frequency")

# Create a summary table
SK_proportions_table <- as.data.frame(t(SK_proportions))
SK_proportions_table <- cbind("BS3-3", SK_proportions_table)
names(SK_proportions_table) <- c("Sample", "Archaea", "Bacteria", "Eukaryota", "Viruses", "Other")
SK_proportions_table <- SK_proportions_table[-c(1,2),]

write.csv(SK_proportions_table, "spades_SK_proportions_table.csv")

save.image("barplot_spades.RData")

#################################################################################################
#################################################################################################


q(save="no")


#################################################################################################
#################################################################################################
#################################################################################################
